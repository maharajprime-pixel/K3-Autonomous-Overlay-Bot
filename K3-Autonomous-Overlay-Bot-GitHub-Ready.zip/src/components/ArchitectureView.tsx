import { useMemo, useState } from 'react';

interface PhaseSpec {
  phase: string;
  title: string;
  trigger: string;
  mechanism: string;
  safetyInvariant: string;
}

const PHASES: PhaseSpec[] = [
  {
    phase: 'Phase A',
    title: 'Round & Timer Monitoring',
    trigger: '500ms Accessibility + ML Kit OCR polling loop',
    mechanism:
      'Extracts the 17-digit Period ID and MM:SS countdown. Tracks lastBetPeriod to enforce strictly one bet per round.',
    safetyInvariant:
      'If remainingSeconds < 10 (00:00–00:09), locks into WAITING_FOR_NEXT_ROUND and blocks all clicks.',
  },
  {
    phase: 'Phase B',
    title: 'Smart Vertical Scroll & Anchoring',
    trigger: 'currentPeriod != lastBetPeriod && remainingSeconds >= 10',
    mechanism:
      'Checks Big 2X / Small 2X Rect bounds against the middle 50% viewport and OverlayService bounding box; dispatches smooth vertical swipe gestures and waits 400ms to re-calculate.',
    safetyInvariant:
      'Up to 2 scroll/locate retries. If bounds remain missing or obstructed, triggers STOPPED - UI ERROR.',
  },
  {
    phase: 'Phase C',
    title: 'Amount Popup Modal Execution',
    trigger: 'Modal opens with Balance, Quantity, I agree, and Total amount',
    mechanism:
      'Taps Base Unit 1, clears & injects active level amount via ACTION_SET_TEXT (or executes optimal Base Unit + Multiplier + "+" tap plan), verifies I agree, and reads Total amount ₹X.XX.',
    safetyInvariant:
      'Strict pre-submit match: if displayed rupee total != active level amount, aborts immediately with STOPPED - UI ERROR.',
  },
  {
    phase: 'Phase D',
    title: 'Result Detection & Progression',
    trigger: 'Countdown reaches 00:00 and Period ID transitions',
    mechanism:
      'Intercepts "Congratulations" / "Sorry" popup and taps circular X close button (+500ms settle). Inspects first row under Game history matching lastBetPeriod to read Big/Small outcome.',
    safetyInvariant:
      'Win resets to Level 1. Loss increments Level N -> N+1. Loss on Level 15 triggers STOPPED - LEVEL 15 LIMIT REACHED with alarm + vibration.',
  },
];

function computeFallbackPlan(targetAmount: number) {
  if (!Number.isFinite(targetAmount) || targetAmount < 1) return null;
  const amount = Math.floor(targetAmount);
  const units = [1000, 100, 10, 1];
  const multipliers = [100, 50, 20, 10, 5, 1];

  let best: { baseUnit: number; multiplierChip: number; plusTaps: number } | null = null;
  let bestCost = Number.MAX_SAFE_INTEGER;

  for (const unit of units) {
    if (amount % unit !== 0) continue;
    const qtyNeeded = amount / unit;
    for (const mult of multipliers) {
      if (mult <= qtyNeeded) {
        const plusTaps = qtyNeeded - mult;
        if (plusTaps >= 0 && plusTaps <= 30 && plusTaps < bestCost) {
          bestCost = plusTaps;
          best = { baseUnit: unit, multiplierChip: mult, plusTaps };
        }
      }
    }
  }

  if (!best) {
    const mult = multipliers.find((m) => m <= amount) ?? 1;
    best = { baseUnit: 1, multiplierChip: mult, plusTaps: amount - mult };
  }
  return best;
}

export function ArchitectureView() {
  const [testAmount, setTestAmount] = useState('250');

  const parsedAmount = Number(testAmount);
  const plan = useMemo(() => computeFallbackPlan(parsedAmount), [parsedAmount]);

  return (
    <div className="space-y-8">
      {/* Deterministic State Machine Matrix */}
      <section className="border border-slate-800 rounded-xl bg-[#111827] overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-800">
          <h2 className="text-base font-semibold text-slate-100">
            Deterministic 4-Phase Automation Pipeline
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Executed inside K3AccessibilityService using hybrid AccessibilityNodeInfo traversal and Google ML Kit Text Recognition v2.
          </p>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-800 text-xs text-slate-400 bg-[#0D131F]">
                <th className="py-3 px-6 font-medium whitespace-nowrap">Phase</th>
                <th className="py-3 px-4 font-medium">Trigger Condition</th>
                <th className="py-3 px-4 font-medium">Execution Mechanism</th>
                <th className="py-3 px-6 font-medium">Safety Invariant</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/80 text-xs">
              {PHASES.map((item) => (
                <tr key={item.phase} className="hover:bg-slate-800/30">
                  <td className="py-4 px-6 align-top whitespace-nowrap">
                    <div className="font-mono font-semibold text-emerald-400">{item.phase}</div>
                    <div className="text-slate-200 font-medium mt-0.5">{item.title}</div>
                  </td>
                  <td className="py-4 px-4 align-top text-slate-300 font-mono">{item.trigger}</td>
                  <td className="py-4 px-4 align-top text-slate-300 leading-relaxed max-w-md">
                    {item.mechanism}
                  </td>
                  <td className="py-4 px-6 align-top text-amber-300/90 leading-relaxed max-w-sm">
                    {item.safetyInvariant}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      {/* Interactive Fallback Quantity Combination Solver */}
      <section className="grid grid-cols-1 lg:grid-cols-2 gap-6 items-stretch">
        <div className="border border-slate-800 rounded-xl bg-[#111827] p-6 flex flex-col justify-between">
          <div>
            <h3 className="text-base font-semibold text-slate-100">
              Phase C Fallback Combination Solver
            </h3>
            <p className="text-xs text-slate-400 mt-1 leading-relaxed">
              When a WebView blocks direct <span className="font-mono text-slate-300">ACTION_SET_TEXT</span> on the Quantity field, <span className="font-mono text-slate-300">buildFallbackAmountPlan()</span> computes the shortest sequence of Balance Base Units (1, 10, 100, 1K), Multiplier chips (X1–X100), and "+" taps.
            </p>

            <div className="mt-5">
              <label
                htmlFor="solver-amount"
                className="block text-xs font-medium text-slate-300 mb-2"
              >
                Test Target Level Amount (Rupees)
              </label>
              <div className="flex items-center gap-3">
                <div className="relative flex-1">
                  <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 font-mono text-sm">
                    ₹
                  </span>
                  <input
                    id="solver-amount"
                    type="number"
                    min={1}
                    max={500000}
                    value={testAmount}
                    onChange={(e) => setTestAmount(e.target.value)}
                    className="w-full bg-[#0B0F17] border border-slate-700 rounded-lg pl-8 pr-4 py-2.5 text-sm font-mono tabular-nums text-slate-100 focus:outline-none focus:border-emerald-500"
                  />
                </div>
                <div className="flex gap-1.5">
                  {[10, 60, 250, 1350].map((preset) => (
                    <button
                      key={preset}
                      type="button"
                      onClick={() => setTestAmount(String(preset))}
                      className="px-3 py-2.5 rounded-lg border border-slate-700 bg-slate-800/70 hover:bg-slate-700 text-xs font-mono tabular-nums text-slate-200 transition-colors whitespace-nowrap"
                    >
                      ₹{preset}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>

          <div className="mt-6 pt-5 border-t border-slate-800">
            {plan ? (
              <div className="grid grid-cols-3 gap-4">
                <div>
                  <div className="text-xs text-slate-400">Balance Unit</div>
                  <div className="text-lg font-mono font-semibold text-slate-100 tabular-nums mt-1">
                    {plan.baseUnit === 1000 ? '1K' : plan.baseUnit}
                  </div>
                </div>
                <div>
                  <div className="text-xs text-slate-400">Multiplier Chip</div>
                  <div className="text-lg font-mono font-semibold text-emerald-400 tabular-nums mt-1">
                    X{plan.multiplierChip}
                  </div>
                </div>
                <div>
                  <div className="text-xs text-slate-400">"+" Button Taps</div>
                  <div className="text-lg font-mono font-semibold text-amber-400 tabular-nums mt-1">
                    {plan.plusTaps}
                  </div>
                </div>
              </div>
            ) : (
              <div className="text-xs text-red-400">
                Enter an integer amount of ₹1 or higher.
              </div>
            )}
          </div>
        </div>

        {/* Hard Safety Limits */}
        <div className="border border-slate-800 rounded-xl bg-[#111827] p-6 flex flex-col justify-between">
          <div>
            <h3 className="text-base font-semibold text-slate-100">
              Mandatory Safety Stops & Zero-Blind-Click Rules
            </h3>
            <p className="text-xs text-slate-400 mt-1 leading-relaxed">
              OverlayService triggers an audible <span className="font-mono text-slate-300">ToneGenerator</span> alarm and 600ms vibration whenever either stop condition fires.
            </p>

            <div className="mt-5 space-y-4 text-xs">
              <div className="pb-4 border-b border-slate-800">
                <div className="font-mono font-semibold text-red-400">
                  STOPPED - LEVEL 15 LIMIT REACHED
                </div>
                <p className="text-slate-300 mt-1 leading-relaxed">
                  Triggered immediately when Phase D verifies a loss on Level 15. Halts the coroutine loop and clears running state without placing Level 16.
                </p>
              </div>

              <div className="pb-4 border-b border-slate-800">
                <div className="font-mono font-semibold text-red-400">
                  STOPPED - UI ERROR
                </div>
                <p className="text-slate-300 mt-1 leading-relaxed">
                  Triggered if Period, Time remaining, Big 2X / Small 2X, Amount Modal, or Game History row cannot be located after 2 retries, or if gesture dispatch fails.
                </p>
              </div>

              <div>
                <div className="font-mono font-semibold text-amber-400">
                  PRE-SUBMIT RUPEE MISMATCH GUARD
                </div>
                <p className="text-slate-300 mt-1 leading-relaxed">
                  Before tapping Total amount ₹X.XX, the engine parses the displayed rupee figure and compares it strictly to the configured level amount. Any mismatch aborts immediately.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
