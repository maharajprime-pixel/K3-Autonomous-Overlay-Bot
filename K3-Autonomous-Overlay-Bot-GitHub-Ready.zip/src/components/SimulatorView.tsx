import React, { useCallback, useEffect, useRef, useState } from 'react';
import { GripHorizontal, Minimize2, Smartphone } from 'lucide-react';

type TargetChoice = 'Big' | 'Small';
type BotState =
  | 'IDLE'
  | 'WAITING FOR NEXT ROUND'
  | 'PLACING BET'
  | 'VERIFYING RESULT'
  | 'STOPPED - LEVEL 15 LIMIT REACHED'
  | 'STOPPED - UI ERROR';

type ForcedOutcome = 'Auto' | 'Force Win' | 'Force Loss';

interface HistoryEntry {
  period: string;
  sum: number;
  outcome: TargetChoice;
}

interface LogEntry {
  id: number;
  time: string;
  phase: string;
  message: string;
}

const DEFAULT_LEVELS = Array.from({ length: 15 }, (_, idx) =>
  Math.min(10 * Math.pow(2, idx), 500000)
);

function formatPeriod(index: number): string {
  return `20261114101010${String(580 + index).padStart(3, '0')}`;
}

export function SimulatorView() {
  // Permissions & Configuration (MainActivity state)
  const [accGranted, setAccGranted] = useState(true);
  const [overlayGranted, setOverlayGranted] = useState(true);
  const [target, setTarget] = useState<TargetChoice>('Big');
  const [levels, setLevels] = useState<number[]>(DEFAULT_LEVELS);
  const [quickBase, setQuickBase] = useState('10');
  const [quickMult, setQuickMult] = useState<2 | 3>(2);
  const [configToast, setConfigToast] = useState<string | null>(null);

  // Floating Overlay state (OverlayService)
  const [overlayVisible, setOverlayVisible] = useState(true);
  const [overlayCollapsed, setOverlayCollapsed] = useState(false);
  const [overlayPos, setOverlayPos] = useState({ x: 16, y: 74 });
  const dragState = useRef<{
    dragging: boolean;
    startX: number;
    startY: number;
    origX: number;
    origY: number;
    moved: boolean;
  }>({ dragging: false, startX: 0, startY: 0, origX: 0, origY: 0, moved: false });

  // K3 Browser & State Machine state
  const [isRunning, setIsRunning] = useState(false);
  const [botState, setBotState] = useState<BotState>('IDLE');
  const [currentLevel, setCurrentLevel] = useState(1);
  const [roundIndex, setRoundIndex] = useState(0);
  const [remainingSeconds, setRemainingSeconds] = useState(34);
  const [lastBetPeriod, setLastBetPeriod] = useState<string | null>(null);
  const [pendingBetPeriod, setPendingBetPeriod] = useState<string | null>(null);
  const [forcedOutcome, setForcedOutcome] = useState<ForcedOutcome>('Auto');
  const [walletBalance, setWalletBalance] = useState(25400);

  // Simulated Modal & Popup state
  const [modalOpen, setModalOpen] = useState(false);
  const [modalUnit, setModalUnit] = useState<1 | 10 | 100 | 1000>(1);
  const [modalQuantity, setModalQuantity] = useState(1);
  const [modalAgreed, setModalAgreed] = useState(true);
  const [resultPopup, setResultPopup] = useState<{
    won: boolean;
    period: string;
    outcome: TargetChoice;
  } | null>(null);

  const [history, setHistory] = useState<HistoryEntry[]>([
    { period: formatPeriod(-1), sum: 14, outcome: 'Big' },
    { period: formatPeriod(-2), sum: 8, outcome: 'Small' },
    { period: formatPeriod(-3), sum: 12, outcome: 'Big' },
    { period: formatPeriod(-4), sum: 6, outcome: 'Small' },
  ]);

  const [logs, setLogs] = useState<LogEntry[]>([
    {
      id: 1,
      time: '03:38:40',
      phase: 'Init',
      message: 'Overlay launched. Press START on the floating widget to begin.',
    },
  ]);

  const phoneScrollRef = useRef<HTMLDivElement>(null);
  const betSectionRef = useRef<HTMLDivElement>(null);
  const automationBusyRef = useRef(false);
  const logCounterRef = useRef(2);

  const currentPeriod = formatPeriod(roundIndex);
  const currentAmount = levels[currentLevel - 1] ?? 10;

  const appendLog = useCallback((phase: string, message: string) => {
    const now = new Date();
    const hh = String(now.getHours()).padStart(2, '0');
    const mm = String(now.getMinutes()).padStart(2, '0');
    const ss = String(now.getSeconds()).padStart(2, '0');
    const id = logCounterRef.current++;
    setLogs((prev) => [{ id, time: `${hh}:${mm}:${ss}`, phase, message }, ...prev].slice(0, 24));
  }, []);

  const showToast = (msg: string) => {
    setConfigToast(msg);
    setTimeout(() => setConfigToast(null), 2200);
  };

  // Quick-Fill handler
  const handleQuickFill = () => {
    const base = Math.max(1, parseInt(quickBase, 10) || 10);
    const next = Array.from({ length: 15 }, (_, i) =>
      Math.min(base * Math.pow(quickMult, i), 10_000_000)
    );
    setLevels(next);
    showToast(`Applied ${quickMult}x progression from ₹${base}`);
  };

  const handleSaveConfig = () => {
    showToast('Configuration saved to SharedPreferences');
    appendLog('Config', `Saved target ${target} and 15 custom levels (L1: ₹${levels[0]})`);
  };

  const handleLaunchOverlay = () => {
    if (!accGranted || !overlayGranted) {
      showToast('Grant Accessibility & Overlay permissions first');
      return;
    }
    setOverlayVisible(true);
    setOverlayCollapsed(false);
    showToast('Floating overlay active');
  };

  // Countdown tick (1s simulated round timer)
  useEffect(() => {
    const timer = setInterval(() => {
      setRemainingSeconds((prev) => {
        if (prev > 0) return prev - 1;

        // Round closed -> settle outcome & advance period
        setRoundIndex((r) => {
          const finishedPeriod = formatPeriod(r);
          const randomSum = Math.floor(Math.random() * 16) + 3;
          let outcome: TargetChoice = randomSum >= 11 ? 'Big' : 'Small';
          if (forcedOutcome === 'Force Win') outcome = target;
          if (forcedOutcome === 'Force Loss') outcome = target === 'Big' ? 'Small' : 'Big';

          const finalSum =
            outcome === 'Big'
              ? Math.max(11, randomSum)
              : Math.min(10, randomSum);

          setHistory((h) => [
            { period: finishedPeriod, sum: finalSum, outcome },
            ...h.slice(0, 7),
          ]);

          setPendingBetPeriod((pending) => {
            if (pending === finishedPeriod) {
              const won = outcome === target;
              setResultPopup({ won, period: finishedPeriod, outcome });
              if (won) {
                setWalletBalance((b) => b + levels[currentLevel - 1] * 2);
              }
            }
            return pending;
          });

          return r + 1;
        });

        return 59;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [forcedOutcome, target, levels, currentLevel]);

  // Deterministic 500ms Accessibility State Machine loop
  useEffect(() => {
    if (!isRunning) return;

    const loop = setInterval(() => {
      if (automationBusyRef.current) return;

      // Phase D: Verify result once period transitions
      if (pendingBetPeriod && currentPeriod !== pendingBetPeriod) {
        automationBusyRef.current = true;
        setBotState('VERIFYING RESULT');

        setTimeout(() => {
          // Dismiss Win/Loss popup if present
          setResultPopup((popup) => {
            if (popup) {
              appendLog(
                'Phase D',
                `Dismissed ${popup.won ? 'Congratulations' : 'Sorry'} popup via X button`
              );
            }
            return null;
          });

          setTimeout(() => {
            const matched = history.find((h) => h.period === pendingBetPeriod);
            if (!matched) {
              setIsRunning(false);
              setBotState('STOPPED - UI ERROR');
              appendLog('Safety', `History row for ${pendingBetPeriod} missing -> UI ERROR`);
              automationBusyRef.current = false;
              return;
            }

            const won = matched.outcome === target;
            setPendingBetPeriod(null);

            if (won) {
              setCurrentLevel(1);
              setBotState('WAITING FOR NEXT ROUND');
              appendLog(
                'Phase D',
                `WIN (${matched.period}: ${matched.outcome}) -> Reset to Level 1 (₹${levels[0]})`
              );
            } else if (currentLevel >= 15) {
              setIsRunning(false);
              setBotState('STOPPED - LEVEL 15 LIMIT REACHED');
              appendLog(
                'Safety',
                `Loss on Level 15 (${matched.period}: ${matched.outcome}) -> Hard Stop`
              );
            } else {
              const nextLv = currentLevel + 1;
              setCurrentLevel(nextLv);
              setBotState('WAITING FOR NEXT ROUND');
              appendLog(
                'Phase D',
                `LOSS (${matched.period}: ${matched.outcome}) -> Level ${nextLv} (₹${levels[nextLv - 1]})`
              );
            }

            automationBusyRef.current = false;
          }, 500);
        }, 450);
        return;
      }

      // Already bet this period
      if (lastBetPeriod === currentPeriod) {
        setBotState('WAITING FOR NEXT ROUND');
        return;
      }

      // Phase A: Timer buffer rule (< 10s locked)
      if (remainingSeconds < 10) {
        setBotState('WAITING FOR NEXT ROUND');
        return;
      }

      // Phase B + Phase C: Place bet on currentPeriod
      automationBusyRef.current = true;
      setBotState('PLACING BET');
      appendLog(
        'Phase B',
        `Centering ${target} 2X button and preparing ₹${currentAmount} (Level ${currentLevel})`
      );

      // Smooth vertical scroll correction if scrolled away
      if (betSectionRef.current && phoneScrollRef.current) {
        betSectionRef.current.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }

      setTimeout(() => {
        setModalUnit(1);
        setModalQuantity(1);
        setModalAgreed(true);
        setModalOpen(true);

        setTimeout(() => {
          setModalQuantity(currentAmount);
          appendLog(
            'Phase C',
            `Injected ₹${currentAmount} into Quantity; verified Total amount ₹${currentAmount}.00`
          );

          setTimeout(() => {
            setModalOpen(false);
            setWalletBalance((b) => Math.max(0, b - currentAmount));
            setLastBetPeriod(currentPeriod);
            setPendingBetPeriod(currentPeriod);
            setBotState('WAITING FOR NEXT ROUND');
            appendLog(
              'Phase C',
              `Confirmed ₹${currentAmount} on ${target} for period ${currentPeriod}`
            );
            automationBusyRef.current = false;
          }, 600);
        }, 500);
      }, 450);
    }, 500);

    return () => clearInterval(loop);
  }, [
    isRunning,
    pendingBetPeriod,
    currentPeriod,
    lastBetPeriod,
    remainingSeconds,
    history,
    target,
    currentLevel,
    currentAmount,
    levels,
    appendLog,
  ]);

  const handleToggleStartStop = () => {
    if (isRunning) {
      setIsRunning(false);
      setBotState('IDLE');
      setModalOpen(false);
      automationBusyRef.current = false;
      appendLog('Control', 'Automation stopped by user');
    } else {
      if (!accGranted || !overlayGranted) {
        showToast('Permissions must be GRANTED before starting');
        return;
      }
      setBotState('WAITING FOR NEXT ROUND');
      setIsRunning(true);
      appendLog('Control', `Started autonomous loop (Target: ${target}, Level ${currentLevel})`);
    }
  };

  // Dragging handlers for OverlayService widget
  const onPointerDownDrag = (e: React.PointerEvent) => {
    dragState.current = {
      dragging: true,
      startX: e.clientX,
      startY: e.clientY,
      origX: overlayPos.x,
      origY: overlayPos.y,
      moved: false,
    };
    (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
  };

  const onPointerMoveDrag = (e: React.PointerEvent) => {
    if (!dragState.current.dragging) return;
    const dx = e.clientX - dragState.current.startX;
    const dy = e.clientY - dragState.current.startY;
    if (Math.abs(dx) > 4 || Math.abs(dy) > 4) dragState.current.moved = true;
    const maxX = overlayCollapsed ? 280 : 120;
    const maxY = overlayCollapsed ? 520 : 410;
    setOverlayPos({
      x: Math.max(8, Math.min(maxX, dragState.current.origX + dx)),
      y: Math.max(44, Math.min(maxY, dragState.current.origY + dy)),
    });
  };

  const onPointerUpDrag = () => {
    const wasMoved = dragState.current.moved;
    dragState.current.dragging = false;
    if (!wasMoved && overlayCollapsed) {
      setOverlayCollapsed(false);
    }
  };

  const triggerTestLevel15Loss = () => {
    setIsRunning(false);
    automationBusyRef.current = false;
    setModalOpen(false);
    setCurrentLevel(15);
    setBotState('STOPPED - LEVEL 15 LIMIT REACHED');
    appendLog('Safety', 'Simulated loss on Level 15 -> Hard Stop & Alert triggered');
  };

  const triggerTestUiError = () => {
    setIsRunning(false);
    automationBusyRef.current = false;
    setModalOpen(false);
    setBotState('STOPPED - UI ERROR');
    appendLog('Safety', 'Simulated missing UI node after 2 retries -> UI Error Stop');
  };

  const handleResetSession = () => {
    setIsRunning(false);
    automationBusyRef.current = false;
    setModalOpen(false);
    setResultPopup(null);
    setCurrentLevel(1);
    setLastBetPeriod(null);
    setPendingBetPeriod(null);
    setBotState('IDLE');
    appendLog('Reset', 'Session reset to Level 1');
  };

  const statusColorClass =
    botState === 'IDLE'
      ? 'text-slate-300'
      : botState === 'WAITING FOR NEXT ROUND'
      ? 'text-amber-400'
      : botState.startsWith('STOPPED')
      ? 'text-red-400'
      : 'text-emerald-400';

  return (
    <div className="grid grid-cols-1 xl:grid-cols-12 gap-6 items-start">
      {/* Left Column: MainActivity Configuration Screen */}
      <section className="xl:col-span-5 border border-slate-800 rounded-xl bg-[#111827] p-5 space-y-5">
        <div className="flex items-center justify-between gap-4 border-b border-slate-800 pb-4">
          <div>
            <h2 className="text-base font-semibold text-slate-100">
              MainActivity Configuration
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Android onboarding, fixed target, and 15-level custom rupee amounts
            </p>
          </div>
          {configToast && (
            <span className="text-xs font-medium text-emerald-400 whitespace-nowrap">
              {configToast}
            </span>
          )}
        </div>

        {/* Permission Onboarding Cards */}
        <div className="space-y-2.5">
          <div className="flex items-center justify-between gap-3 p-3.5 rounded-lg bg-[#0B0F17] border border-slate-800">
            <div>
              <div className="text-xs font-semibold text-slate-100">Accessibility Service</div>
              <div className="text-xs text-slate-400 mt-0.5">
                Reads timer, nodes, and dispatches gestures
              </div>
            </div>
            <div className="flex items-center gap-2 shrink-0">
              <span
                className={`text-xs font-mono font-semibold px-2 py-1 rounded ${
                  accGranted
                    ? 'bg-emerald-500/15 text-emerald-400'
                    : 'bg-red-500/15 text-red-400'
                }`}
              >
                {accGranted ? 'GRANTED' : 'MISSING'}
              </span>
              <button
                type="button"
                onClick={() => setAccGranted((v) => !v)}
                className="px-3 py-1.5 rounded-lg border border-slate-700 bg-slate-800 hover:bg-slate-700 text-xs font-medium text-slate-200 transition-colors"
              >
                {accGranted ? 'Revoke' : 'Enable'}
              </button>
            </div>
          </div>

          <div className="flex items-center justify-between gap-3 p-3.5 rounded-lg bg-[#0B0F17] border border-slate-800">
            <div>
              <div className="text-xs font-semibold text-slate-100">Display Over Other Apps</div>
              <div className="text-xs text-slate-400 mt-0.5">
                Draws the draggable floating control overlay
              </div>
            </div>
            <div className="flex items-center gap-2 shrink-0">
              <span
                className={`text-xs font-mono font-semibold px-2 py-1 rounded ${
                  overlayGranted
                    ? 'bg-emerald-500/15 text-emerald-400'
                    : 'bg-red-500/15 text-red-400'
                }`}
              >
                {overlayGranted ? 'GRANTED' : 'MISSING'}
              </span>
              <button
                type="button"
                onClick={() => setOverlayGranted((v) => !v)}
                className="px-3 py-1.5 rounded-lg border border-slate-700 bg-slate-800 hover:bg-slate-700 text-xs font-medium text-slate-200 transition-colors"
              >
                {overlayGranted ? 'Revoke' : 'Grant'}
              </button>
            </div>
          </div>
        </div>

        {/* Fixed Target Selector */}
        <div>
          <div className="text-xs font-semibold text-slate-200 mb-2">
            Fixed Prediction Target
          </div>
          <div className="grid grid-cols-2 gap-1 p-1 rounded-lg bg-[#0B0F17] border border-slate-800">
            {(['Big', 'Small'] as TargetChoice[]).map((choice) => {
              const active = target === choice;
              return (
                <button
                  key={choice}
                  type="button"
                  disabled={isRunning}
                  onClick={() => setTarget(choice)}
                  className={`py-2 rounded-md text-xs font-semibold transition-colors ${
                    active
                      ? 'bg-emerald-600 text-white'
                      : 'text-slate-400 hover:text-slate-200'
                  } ${isRunning ? 'opacity-60 cursor-not-allowed' : ''}`}
                >
                  {choice} (2X)
                </button>
              );
            })}
          </div>
        </div>

        {/* Quick-Fill Helper Bar */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-semibold text-slate-200">
              Custom 15-Level Amount Manager
            </span>
            <span className="text-xs text-slate-400">Rupees (₹)</span>
          </div>

          <div className="flex items-center gap-2 p-2 rounded-lg bg-[#0B0F17] border border-slate-800 mb-3">
            <input
              type="number"
              min={1}
              value={quickBase}
              onChange={(e) => setQuickBase(e.target.value)}
              aria-label="Quick-fill base amount"
              className="w-24 bg-[#111827] border border-slate-700 rounded-md px-2.5 py-1.5 text-xs font-mono tabular-nums text-slate-100 focus:outline-none focus:border-emerald-500"
            />
            <div className="flex items-center gap-1 p-0.5 rounded-md bg-[#111827] border border-slate-800">
              {([2, 3] as const).map((m) => (
                <button
                  key={m}
                  type="button"
                  onClick={() => setQuickMult(m)}
                  className={`px-2.5 py-1 rounded text-xs font-mono font-semibold transition-colors ${
                    quickMult === m
                      ? 'bg-slate-700 text-white'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {m}x
                </button>
              ))}
            </div>
            <button
              type="button"
              onClick={handleQuickFill}
              className="ml-auto px-3 py-1.5 rounded-md bg-blue-600 hover:bg-blue-500 text-xs font-semibold text-white transition-colors whitespace-nowrap"
            >
              Apply
            </button>
          </div>

          {/* 15 Individual Numbered Inputs */}
          <div className="grid grid-cols-3 gap-2 max-h-[260px] overflow-y-auto pr-1">
            {levels.map((val, idx) => (
              <div
                key={idx}
                className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-[#0B0F17] border ${
                  currentLevel === idx + 1
                    ? 'border-emerald-500/70'
                    : 'border-slate-800'
                }`}
              >
                <span className="text-[11px] font-mono text-slate-400 w-7 shrink-0 tabular-nums">
                  L{idx + 1}
                </span>
                <span className="text-[11px] font-mono text-slate-500">₹</span>
                <input
                  type="number"
                  min={1}
                  value={val}
                  onChange={(e) => {
                    const parsed = Math.max(1, parseInt(e.target.value, 10) || 1);
                    setLevels((prev) => prev.map((x, i) => (i === idx ? parsed : x)));
                  }}
                  aria-label={`Level ${idx + 1} amount`}
                  className="w-full bg-transparent text-xs font-mono tabular-nums text-slate-100 focus:outline-none"
                />
              </div>
            ))}
          </div>
        </div>

        {/* Save & Launch Buttons */}
        <div className="grid grid-cols-2 gap-3 pt-1">
          <button
            type="button"
            onClick={handleSaveConfig}
            className="py-2.5 px-4 rounded-lg border border-slate-700 bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-100 transition-colors"
          >
            Save Configuration
          </button>
          <button
            type="button"
            onClick={handleLaunchOverlay}
            className="py-2.5 px-4 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-xs font-semibold text-white transition-colors"
          >
            Launch Overlay
          </button>
        </div>
      </section>

      {/* Right Column: Live Android Browser + Draggable Overlay + Telemetry Log */}
      <section className="xl:col-span-7 grid grid-cols-1 lg:grid-cols-[360px_1fr] gap-6 items-start">
        {/* Simulated Mobile Screen */}
        <div className="relative mx-auto w-[360px] h-[660px] rounded-[28px] border-4 border-slate-800 bg-[#0B0F17] overflow-hidden shadow-2xl select-none">
          {/* Android Browser URL Bar */}
          <div className="h-11 bg-[#161E2E] border-b border-slate-800 px-3 flex items-center gap-2">
            <Smartphone className="w-3.5 h-3.5 text-slate-400 shrink-0" />
            <div className="flex-1 bg-[#0B0F17] rounded-md px-2.5 py-1 text-[11px] font-mono text-slate-300 truncate">
              damangames.bio/#/saasLottery/K3?gameCode=K3_1M&amp;lottery=K3
            </div>
          </div>

          {/* Scrollable K3 Lottery Webpage */}
          <div
            ref={phoneScrollRef}
            className="h-[615px] overflow-y-auto bg-[#F8FAFC] text-slate-900 p-3 space-y-3"
          >
            {/* Wallet Banner (above fold if user scrolls up) */}
            <div className="rounded-xl bg-gradient-to-r from-rose-600 to-red-500 text-white p-3.5">
              <div className="text-xs opacity-90">Wallet Balance</div>
              <div className="text-xl font-mono font-bold tabular-nums mt-0.5">
                ₹{walletBalance.toLocaleString('en-IN')}.00
              </div>
            </div>

            {/* Period & Countdown Header */}
            <div className="rounded-xl bg-white border border-slate-200 p-3 flex items-center justify-between">
              <div>
                <div className="text-[11px] text-slate-500">Period</div>
                <div className="text-xs font-mono font-bold tabular-nums text-slate-900 mt-0.5">
                  {currentPeriod}
                </div>
              </div>
              <div className="text-right">
                <div className="text-[11px] text-slate-500">Time remaining</div>
                <div
                  className={`text-base font-mono font-bold tabular-nums mt-0.5 ${
                    remainingSeconds < 10 ? 'text-red-600' : 'text-slate-900'
                  }`}
                >
                  00 : {String(remainingSeconds).padStart(2, '0')}
                </div>
              </div>
            </div>

            {/* K3 Betting Options (Total Big 2X / Small 2X) */}
            <div
              ref={betSectionRef}
              className="rounded-xl bg-white border border-slate-200 p-3 space-y-2.5"
            >
              <div className="flex items-center justify-between text-xs font-semibold text-slate-700">
                <span>Total</span>
                <span className="text-[11px] font-normal text-slate-500">
                  K3 1-Minute
                </span>
              </div>

              <div className="grid grid-cols-2 gap-2.5">
                <div
                  className={`rounded-lg p-3 text-center border transition-colors ${
                    target === 'Big' && botState === 'PLACING BET'
                      ? 'bg-amber-500 text-white border-amber-600'
                      : 'bg-amber-50 text-amber-800 border-amber-200'
                  }`}
                >
                  <div className="text-sm font-bold">Big 2X</div>
                  <div className="text-[11px] opacity-80">11–18</div>
                </div>
                <div
                  className={`rounded-lg p-3 text-center border transition-colors ${
                    target === 'Small' && botState === 'PLACING BET'
                      ? 'bg-blue-600 text-white border-blue-700'
                      : 'bg-blue-50 text-blue-800 border-blue-200'
                  }`}
                >
                  <div className="text-sm font-bold">Small 2X</div>
                  <div className="text-[11px] opacity-80">3–10</div>
                </div>
              </div>
            </div>

            {/* Game History Table */}
            <div className="rounded-xl bg-white border border-slate-200 overflow-hidden">
              <div className="px-3 py-2 bg-slate-100 border-b border-slate-200 text-xs font-semibold text-slate-800">
                Game history
              </div>
              <table className="w-full text-left text-[11px]">
                <thead>
                  <tr className="border-b border-slate-200 text-slate-500">
                    <th className="py-2 px-2.5 font-medium">Period</th>
                    <th className="py-2 px-2 font-medium text-center">Sum</th>
                    <th className="py-2 px-2.5 font-medium text-right">Results</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {history.map((row) => (
                    <tr key={row.period}>
                      <td className="py-2 px-2.5 font-mono tabular-nums text-slate-700">
                        {row.period}
                      </td>
                      <td className="py-2 px-2 font-mono tabular-nums text-center font-semibold text-slate-900">
                        {row.sum}
                      </td>
                      <td className="py-2 px-2.5 text-right font-semibold">
                        <span
                          className={
                            row.outcome === 'Big' ? 'text-amber-600' : 'text-blue-600'
                          }
                        >
                          {row.outcome}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Phase C: Simulated Amount Popup Modal */}
          {modalOpen && (
            <div className="absolute inset-x-0 bottom-0 bg-white text-slate-900 rounded-t-2xl border-t border-slate-300 p-4 shadow-2xl z-20 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-800">
                  K3 1-Min · {target} 2X
                </span>
                <span className="text-[11px] text-slate-500">Phase C Modal</span>
              </div>

              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-600">Balance</span>
                <div className="flex gap-1.5">
                  {([1, 10, 100, 1000] as const).map((unit) => (
                    <span
                      key={unit}
                      className={`px-2.5 py-1 rounded font-mono text-[11px] font-semibold ${
                        modalUnit === unit
                          ? 'bg-red-500 text-white'
                          : 'bg-slate-100 text-slate-700'
                      }`}
                    >
                      {unit === 1000 ? '1K' : unit}
                    </span>
                  ))}
                </div>
              </div>

              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-600">Quantity</span>
                <div className="flex items-center gap-2">
                  <span className="w-7 h-7 rounded bg-slate-100 flex items-center justify-center font-bold">
                    -
                  </span>
                  <span className="w-20 h-7 rounded border border-slate-300 flex items-center justify-center font-mono tabular-nums font-bold">
                    {modalQuantity}
                  </span>
                  <span className="w-7 h-7 rounded bg-slate-100 flex items-center justify-center font-bold">
                    +
                  </span>
                </div>
              </div>

              <div className="flex items-center justify-between text-[11px] text-slate-600">
                <span>{modalAgreed ? '☑' : '☐'} I agree pre-sale rules</span>
              </div>

              <div className="w-full py-2.5 rounded-lg bg-red-600 text-white text-center text-xs font-mono font-bold tabular-nums">
                Total amount ₹{modalUnit * modalQuantity}.00
              </div>
            </div>
          )}

          {/* Phase D: Win/Loss Result Popup Overlay */}
          {resultPopup && (
            <div className="absolute inset-0 bg-black/60 flex flex-col items-center justify-center p-6 z-30">
              <div className="w-full rounded-2xl bg-white text-slate-900 p-5 text-center space-y-2">
                <div
                  className={`text-lg font-bold ${
                    resultPopup.won ? 'text-emerald-600' : 'text-red-600'
                  }`}
                >
                  {resultPopup.won ? 'Congratulations' : 'Sorry'}
                </div>
                <div className="text-xs text-slate-600 font-mono tabular-nums">
                  Period {resultPopup.period}
                </div>
                <div className="text-sm font-semibold text-slate-800">
                  Outcome: {resultPopup.outcome}
                </div>
              </div>
              <button
                type="button"
                onClick={() => setResultPopup(null)}
                className="mt-4 w-9 h-9 rounded-full border border-white/70 text-white flex items-center justify-center text-sm font-bold"
              >
                ✕
              </button>
            </div>
          )}

          {/* Draggable Floating OverlayService Widget */}
          {overlayVisible && (
            <div
              style={{
                transform: `translate(${overlayPos.x}px, ${overlayPos.y}px)`,
              }}
              className="absolute top-0 left-0 z-40"
            >
              {overlayCollapsed ? (
                <button
                  type="button"
                  onPointerDown={onPointerDownDrag}
                  onPointerMove={onPointerMoveDrag}
                  onPointerUp={onPointerUpDrag}
                  className="w-12 h-12 rounded-full bg-[#0F172A]/95 border-2 border-emerald-500 text-xs font-mono font-bold text-slate-100 shadow-xl flex items-center justify-center cursor-grab active:cursor-grabbing"
                >
                  L{currentLevel}
                </button>
              ) : (
                <div className="w-[224px] rounded-xl bg-[#0F172A]/95 border border-slate-700 p-2.5 shadow-2xl text-slate-100 backdrop-blur-sm">
                  <div
                    onPointerDown={onPointerDownDrag}
                    onPointerMove={onPointerMoveDrag}
                    onPointerUp={onPointerUpDrag}
                    className="flex items-center justify-between gap-1.5 pb-2 cursor-grab active:cursor-grabbing"
                  >
                    <div className="flex items-center gap-1.5 text-xs font-bold">
                      <GripHorizontal className="w-3.5 h-3.5 text-slate-400" />
                      <span>K3 Auto Bot</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <button
                        type="button"
                        disabled={isRunning}
                        onClick={() =>
                          setTarget((t) => (t === 'Big' ? 'Small' : 'Big'))
                        }
                        className={`px-2 py-0.5 rounded bg-[#0B0F17] border border-slate-700 text-[11px] font-semibold ${
                          isRunning ? 'opacity-50 cursor-not-allowed' : ''
                        }`}
                      >
                        {target}
                      </button>
                      <button
                        type="button"
                        onClick={() => setOverlayCollapsed(true)}
                        aria-label="Minimize overlay"
                        className="p-1 rounded bg-[#0B0F17] border border-slate-700 text-slate-400 hover:text-white"
                      >
                        <Minimize2 className="w-3 h-3" />
                      </button>
                    </div>
                  </div>

                  <div
                    className={`px-2 py-1 rounded bg-[#0B0F17] border border-slate-800 text-[10px] font-mono font-semibold mb-2 truncate ${statusColorClass}`}
                  >
                    {botState}
                  </div>

                  <div className="flex items-center justify-between text-[10px] mb-1">
                    <span className="text-slate-400">Period</span>
                    <span className="font-mono tabular-nums text-slate-200">
                      {currentPeriod}
                    </span>
                  </div>

                  <div className="flex items-center justify-between text-xs font-mono font-semibold mb-2.5 tabular-nums">
                    <span className="text-slate-300">Level {currentLevel} / 15</span>
                    <span className="text-emerald-400">₹{currentAmount}</span>
                  </div>

                  <button
                    type="button"
                    onClick={handleToggleStartStop}
                    className={`w-full py-1.5 rounded-lg text-xs font-bold text-white transition-colors ${
                      isRunning
                        ? 'bg-red-600 hover:bg-red-500'
                        : 'bg-emerald-600 hover:bg-emerald-500'
                    }`}
                  >
                    {isRunning ? 'STOP' : 'START'}
                  </button>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Fault Injection & Chronological Event Log */}
        <div className="space-y-4">
          <div className="border border-slate-800 rounded-xl bg-[#111827] p-4 space-y-3">
            <h3 className="text-sm font-semibold text-slate-100">
              State Machine Test Controls
            </h3>

            <div>
              <div className="text-xs text-slate-400 mb-1.5">Next Round Outcome</div>
              <div className="grid grid-cols-3 gap-1 p-1 rounded-lg bg-[#0B0F17] border border-slate-800">
                {(['Auto', 'Force Win', 'Force Loss'] as ForcedOutcome[]).map((mode) => (
                  <button
                    key={mode}
                    type="button"
                    onClick={() => setForcedOutcome(mode)}
                    className={`py-1.5 rounded text-xs font-medium transition-colors ${
                      forcedOutcome === mode
                        ? 'bg-slate-700 text-white'
                        : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    {mode}
                  </button>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2 pt-1">
              <button
                type="button"
                onClick={() => setRemainingSeconds(8)}
                className="py-2 px-3 rounded-lg border border-slate-700 bg-slate-800/80 hover:bg-slate-700 text-xs font-medium text-slate-200 transition-colors"
              >
                Skip to 00:08
              </button>
              <button
                type="button"
                onClick={triggerTestLevel15Loss}
                className="py-2 px-3 rounded-lg border border-slate-700 bg-slate-800/80 hover:bg-slate-700 text-xs font-medium text-amber-300 transition-colors"
              >
                Test L15 Stop
              </button>
              <button
                type="button"
                onClick={triggerTestUiError}
                className="py-2 px-3 rounded-lg border border-slate-700 bg-slate-800/80 hover:bg-slate-700 text-xs font-medium text-red-300 transition-colors"
              >
                Test UI Error
              </button>
              <button
                type="button"
                onClick={handleResetSession}
                className="py-2 px-3 rounded-lg border border-slate-700 bg-slate-800/80 hover:bg-slate-700 text-xs font-medium text-slate-200 transition-colors"
              >
                Reset Session
              </button>
            </div>
          </div>

          {/* Execution Log Table */}
          <div className="border border-slate-800 rounded-xl bg-[#111827] overflow-hidden">
            <div className="px-4 py-3 border-b border-slate-800 flex items-center justify-between">
              <span className="text-xs font-semibold text-slate-200">
                Execution Trace
              </span>
              <span className="text-xs font-mono text-slate-400 tabular-nums">
                500ms loop
              </span>
            </div>
            <div className="max-h-[380px] overflow-y-auto divide-y divide-slate-800/70">
              {logs.map((entry) => (
                <div key={entry.id} className="px-4 py-2.5 text-xs space-y-0.5">
                  <div className="flex items-center justify-between text-[11px] font-mono">
                    <span className="text-emerald-400 font-semibold">{entry.phase}</span>
                    <span className="text-slate-500 tabular-nums">{entry.time}</span>
                  </div>
                  <div className="text-slate-300 leading-snug">{entry.message}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
