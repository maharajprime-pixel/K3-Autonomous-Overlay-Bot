import { Download } from 'lucide-react';
import { downloadAndroidProjectZip } from '../data/androidProjectFiles';

export function BuildGuideView() {
  return (
    <div className="max-w-4xl space-y-6">
      <section className="border border-slate-800 rounded-xl bg-[#111827] p-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-5 border-b border-slate-800">
          <div>
            <h2 className="text-lg font-semibold text-slate-100">
              Compile & Deploy on Android (API 24 – API 35)
            </h2>
            <p className="text-xs text-slate-400 mt-1">
              Target SDK 35 · Minimum SDK 24 (Android 7.0) · Kotlin 2.0 · ML Kit Text Recognition 16.0.1
            </p>
          </div>
          <button
            type="button"
            onClick={() => void downloadAndroidProjectZip()}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-xs font-semibold text-white transition-colors whitespace-nowrap shrink-0"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Download Android ZIP</span>
          </button>
        </div>

        <ol className="mt-6 space-y-6 text-sm text-slate-300">
          <li className="space-y-2">
            <div className="font-semibold text-slate-100">
              1. Open in Android Studio Ladybug or Newer
            </div>
            <p className="text-xs text-slate-400 leading-relaxed">
              Extract <span className="font-mono text-slate-200">K3OverlayBot-Android.zip</span> and open the root folder in Android Studio. Let Gradle sync download AndroidX Lifecycle Service, Material 3, and <span className="font-mono text-slate-200">com.google.mlkit:text-recognition:16.0.1</span>.
            </p>
          </li>

          <li className="space-y-2">
            <div className="font-semibold text-slate-100">
              2. Build & Install APK via ADB
            </div>
            <pre className="bg-[#0B0F17] border border-slate-800 rounded-lg p-3.5 text-xs font-mono text-slate-200 overflow-x-auto">
{`./gradlew assembleDebug
adb install -r app/build/outputs/apk/debug/app-debug.apk`}
            </pre>
          </li>

          <li className="space-y-2">
            <div className="font-semibold text-slate-100">
              3. Enable Restricted Accessibility Setting (Android 13–15 Sideload Note)
            </div>
            <p className="text-xs text-slate-400 leading-relaxed">
              When sideloading APKs outside Google Play on Android 13+, Android restricts Accessibility Services until allowed in App Info: open <span className="font-mono text-slate-200">Settings → Apps → K3 Overlay Bot → ⋮ (Top Right) → Allow restricted settings</span>, then tap <span className="font-mono text-slate-200">Settings</span> on the Accessibility card inside the app to toggle <span className="font-mono text-slate-200">K3 Autonomous Overlay Engine</span> ON.
            </p>
          </li>

          <li className="space-y-2">
            <div className="font-semibold text-slate-100">
              4. Grant Overlay Permission & Configure Levels
            </div>
            <p className="text-xs text-slate-400 leading-relaxed">
              Tap <span className="font-mono text-slate-200">Grant</span> on Display Over Other Apps, lock your fixed target (<span className="font-mono text-slate-200">Big</span> or <span className="font-mono text-slate-200">Small</span>), configure Levels 1–15 manually or via Quick-Fill, tap <span className="font-mono text-slate-200">Save Configuration</span>, and press <span className="font-mono text-slate-200">Launch Floating Overlay</span>.
            </p>
          </li>
        </ol>
      </section>
    </div>
  );
}
