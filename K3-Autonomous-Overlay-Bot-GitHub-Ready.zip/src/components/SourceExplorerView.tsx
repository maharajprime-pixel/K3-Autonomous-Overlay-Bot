import { useMemo, useState } from 'react';
import { Check, Copy, FileCode2, Search } from 'lucide-react';
import { androidProjectFiles, ProjectFile } from '../data/androidProjectFiles';

const CATEGORIES: ProjectFile['category'][] = [
  'Kotlin Source',
  'Gradle & Manifest',
  'XML Layouts',
  'Resources',
];

export function SourceExplorerView() {
  const [selectedPath, setSelectedPath] = useState<string>(
    androidProjectFiles[2]?.path ?? androidProjectFiles[0]?.path ?? ''
  );
  const [searchQuery, setSearchQuery] = useState('');
  const [copied, setCopied] = useState(false);

  const filteredFiles = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    if (!q) return androidProjectFiles;
    return androidProjectFiles.filter(
      (f) =>
        f.name.toLowerCase().includes(q) ||
        f.path.toLowerCase().includes(q) ||
        f.content.toLowerCase().includes(q)
    );
  }, [searchQuery]);

  const activeFile = useMemo(
    () =>
      androidProjectFiles.find((f) => f.path === selectedPath) ??
      filteredFiles[0] ??
      androidProjectFiles[0],
    [selectedPath, filteredFiles]
  );

  const handleCopy = async () => {
    if (!activeFile) return;
    await navigator.clipboard.writeText(activeFile.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 1600);
  };

  const lines = useMemo(
    () => (activeFile ? activeFile.content.split('\n') : []),
    [activeFile]
  );

  return (
    <div className="grid grid-cols-1 lg:grid-cols-[280px_1fr] border border-slate-800 rounded-xl overflow-hidden bg-[#111827] min-h-[720px]">
      {/* File Tree Sidebar */}
      <aside className="border-b lg:border-b-0 lg:border-r border-slate-800 bg-[#0D131F] flex flex-col">
        <div className="p-3 border-b border-slate-800">
          <div className="relative">
            <Search className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Filter files or symbols"
              className="w-full bg-[#0B0F17] border border-slate-800 rounded-lg pl-9 pr-3 py-2 text-xs text-slate-200 placeholder:text-slate-500 focus:outline-none focus:border-emerald-500/60"
            />
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-3 space-y-5 max-h-[680px]">
          {CATEGORIES.map((category) => {
            const items = filteredFiles.filter((f) => f.category === category);
            if (items.length === 0) return null;
            return (
              <div key={category}>
                <div className="text-xs font-medium text-slate-400 px-2 mb-1.5">
                  {category}
                </div>
                <div className="space-y-0.5">
                  {items.map((file) => {
                    const isSelected = activeFile?.path === file.path;
                    return (
                      <button
                        key={file.path}
                        type="button"
                        onClick={() => setSelectedPath(file.path)}
                        className={`w-full text-left px-2.5 py-2 rounded-lg text-xs flex items-center gap-2 transition-colors ${
                          isSelected
                            ? 'bg-emerald-500/15 text-emerald-300 font-medium'
                            : 'text-slate-300 hover:bg-slate-800/70'
                        }`}
                      >
                        <FileCode2 className="w-3.5 h-3.5 shrink-0 opacity-75" />
                        <span className="truncate font-mono">{file.name}</span>
                      </button>
                    );
                  })}
                </div>
              </div>
            );
          })}

          {filteredFiles.length === 0 && (
            <div className="text-xs text-slate-500 px-2 py-4">
              No matching Android files found.
            </div>
          )}
        </div>
      </aside>

      {/* Code Viewer */}
      <section className="flex flex-col min-w-0 bg-[#0B0F17]">
        {activeFile ? (
          <>
            <div className="flex items-center justify-between gap-4 px-4 py-3 border-b border-slate-800 bg-[#111827]">
              <div className="min-w-0">
                <div className="text-xs font-mono text-slate-200 truncate">
                  {activeFile.path}
                </div>
                <div className="text-xs text-slate-400 mt-0.5 flex items-center gap-2">
                  <span>{activeFile.category}</span>
                  <span aria-hidden="true">·</span>
                  <span className="tabular-nums">{lines.length} lines</span>
                </div>
              </div>

              <button
                type="button"
                onClick={handleCopy}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-700 bg-slate-800/80 hover:bg-slate-700 text-xs font-medium text-slate-200 transition-colors whitespace-nowrap shrink-0"
              >
                {copied ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Copied</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>Copy File</span>
                  </>
                )}
              </button>
            </div>

            <div className="flex-1 overflow-auto p-4 max-h-[680px]">
              <table className="w-full border-collapse text-xs font-mono leading-relaxed">
                <tbody>
                  {lines.map((line, idx) => (
                    <tr key={idx} className="hover:bg-slate-800/30">
                      <td className="select-none pr-4 text-right text-slate-600 tabular-nums align-top w-10">
                        {idx + 1}
                      </td>
                      <td className="text-slate-200 whitespace-pre">{line || ' '}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </>
        ) : (
          <div className="p-8 text-sm text-slate-400">Select a file to inspect its code.</div>
        )}
      </section>
    </div>
  );
}
