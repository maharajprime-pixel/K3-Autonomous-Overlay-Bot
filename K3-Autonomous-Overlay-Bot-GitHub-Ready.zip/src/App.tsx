import { useState } from 'react';
import { Download } from 'lucide-react';
import { ArchitectureView } from './components/ArchitectureView';
import { BuildGuideView } from './components/BuildGuideView';
import { SimulatorView } from './components/SimulatorView';
import { SourceExplorerView } from './components/SourceExplorerView';
import {
  androidProjectFiles,
  downloadAndroidProjectZip,
} from './data/androidProjectFiles';

type ActiveTab = 'simulator' | 'source' | 'architecture' | 'build';

const NAV_ITEMS: { id: ActiveTab; label: string }[] = [
  { id: 'simulator', label: 'Simulator' },
  { id: 'source', label: 'Source Code' },
  { id: 'architecture', label: 'State Machine' },
  { id: 'build', label: 'Build Guide' },
];

export default function App() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('simulator');
  const [downloading, setDownloading] = useState(false);

  const handleDownload = async () => {
    setDownloading(true);
    try {
      await downloadAndroidProjectZip();
    } finally {
      setDownloading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#0B0F17] text-slate-100 flex flex-col">
      {/* 3-Zone Top Bar Contract */}
      <header className="border-b border-slate-800/90 bg-[#0B0F17]/95 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-[1380px] mx-auto px-6 h-16 flex items-center justify-between gap-8">
          <a
            href="#top"
            onClick={(e) => {
              e.preventDefault();
              setActiveTab('simulator');
            }}
            className="font-display text-base font-bold tracking-tight text-slate-100 whitespace-nowrap shrink-0"
          >
            K3 Overlay Studio
          </a>

          <nav className="flex items-center gap-6 overflow-x-auto">
            {NAV_ITEMS.map((item) => {
              const active = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => setActiveTab(item.id)}
                  className={`text-sm font-medium transition-colors whitespace-nowrap shrink-0 py-1 border-b-2 ${
                    active
                      ? 'text-slate-100 border-emerald-500'
                      : 'text-slate-400 border-transparent hover:text-slate-200'
                  }`}
                >
                  {item.label}
                </button>
              );
            })}
          </nav>

          <div className="shrink-0">
            <button
              type="button"
              disabled={downloading}
              onClick={() => void handleDownload()}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 disabled:opacity-60 text-xs font-semibold text-white transition-colors whitespace-nowrap shrink-0"
            >
              <Download className="w-3.5 h-3.5" />
              <span>{downloading ? 'Packaging...' : 'Download Project'}</span>
            </button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 max-w-[1380px] w-full mx-auto px-6 py-6">
        <div className="mb-6 flex flex-col sm:flex-row sm:items-end justify-between gap-3">
          <div>
            <h1 className="font-display text-2xl font-bold tracking-tight text-slate-100 text-balance">
              Autonomous K3 1-Minute Overlay Bot
            </h1>
            <p className="text-xs text-slate-400 mt-1 flex flex-wrap items-center gap-2">
              <span>Native Android Kotlin</span>
              <span aria-hidden="true">·</span>
              <span>API 24–35</span>
              <span aria-hidden="true">·</span>
              <span>ML Kit Text Recognition v2</span>
              <span aria-hidden="true">·</span>
              <span className="tabular-nums">{androidProjectFiles.length} project files</span>
            </p>
          </div>
        </div>

        {activeTab === 'simulator' && <SimulatorView />}
        {activeTab === 'source' && <SourceExplorerView />}
        {activeTab === 'architecture' && <ArchitectureView />}
        {activeTab === 'build' && <BuildGuideView />}
      </main>
    </div>
  );
}
