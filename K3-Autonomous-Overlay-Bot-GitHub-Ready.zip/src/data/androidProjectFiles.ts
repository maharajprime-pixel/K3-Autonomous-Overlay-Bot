import JSZip from 'jszip';

export interface ProjectFile {
  path: string;
  name: string;
  category: 'Gradle & Manifest' | 'Kotlin Source' | 'XML Layouts' | 'Resources';
  language: 'kotlin' | 'xml' | 'gradle' | 'text';
  content: string;
}

const rawModules = import.meta.glob('/android-app/**/*', {
  query: '?raw',
  import: 'default',
  eager: true,
}) as Record<string, string>;

function inferCategory(path: string): ProjectFile['category'] {
  if (
    path.endsWith('.gradle.kts') ||
    path.endsWith('gradle.properties') ||
    path.endsWith('proguard-rules.pro') ||
    path.endsWith('AndroidManifest.xml') ||
    path.includes('/res/xml/')
  ) {
    return 'Gradle & Manifest';
  }
  if (path.endsWith('.kt')) {
    return 'Kotlin Source';
  }
  if (path.includes('/res/layout/')) {
    return 'XML Layouts';
  }
  return 'Resources';
}

function inferLanguage(path: string): ProjectFile['language'] {
  if (path.endsWith('.kt')) return 'kotlin';
  if (path.endsWith('.xml')) return 'xml';
  if (path.endsWith('.gradle.kts')) return 'gradle';
  return 'text';
}

const priorityOrder = [
  'app/src/main/AndroidManifest.xml',
  'app/src/main/res/xml/accessibility_service_config.xml',
  'app/src/main/java/com/k3bot/overlay/service/K3AccessibilityService.kt',
  'app/src/main/java/com/k3bot/overlay/service/OverlayService.kt',
  'app/src/main/java/com/k3bot/overlay/ocr/OcrHelper.kt',
  'app/src/main/java/com/k3bot/overlay/ui/MainActivity.kt',
  'app/src/main/java/com/k3bot/overlay/data/BotConfig.kt',
  'app/src/main/java/com/k3bot/overlay/data/PrefsManager.kt',
  'app/src/main/res/layout/activity_main.xml',
  'app/src/main/res/layout/layout_overlay_widget.xml',
  'app/src/main/res/layout/item_level_row.xml',
  'app/build.gradle.kts',
];

export const androidProjectFiles: ProjectFile[] = Object.entries(rawModules)
  .map(([fullPath, content]) => {
    const cleanPath = fullPath.replace(/^\/android-app\//, '');
    const parts = cleanPath.split('/');
    return {
      path: cleanPath,
      name: parts[parts.length - 1],
      category: inferCategory(cleanPath),
      language: inferLanguage(cleanPath),
      content,
    };
  })
  .sort((a, b) => {
    const ia = priorityOrder.indexOf(a.path);
    const ib = priorityOrder.indexOf(b.path);
    if (ia !== -1 && ib !== -1) return ia - ib;
    if (ia !== -1) return -1;
    if (ib !== -1) return 1;
    return a.path.localeCompare(b.path);
  });

export async function downloadAndroidProjectZip(): Promise<void> {
  const zip = new JSZip();
  for (const file of androidProjectFiles) {
    zip.file(`K3OverlayBot/${file.path}`, file.content);
  }
  const blob = await zip.generateAsync({ type: 'blob' });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = 'K3OverlayBot-Android.zip';
  document.body.appendChild(anchor);
  anchor.click();
  document.body.removeChild(anchor);
  URL.revokeObjectURL(url);
}
