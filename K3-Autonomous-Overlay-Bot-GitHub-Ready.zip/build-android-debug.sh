#!/usr/bin/env bash
set -euo pipefail
gradle -p android-app --no-daemon assembleDebug
echo "APK: android-app/app/build/outputs/apk/debug/app-debug.apk"
