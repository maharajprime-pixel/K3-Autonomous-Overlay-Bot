# K3 Autonomous Overlay Bot Studio

This repository contains two parts:

- `android-app/` — native Android application written in Kotlin.
- `src/` and the root web files — browser-based Studio and simulator (Vite + React).

## Build an Android APK on GitHub

The repository includes a GitHub Actions workflow at
`.github/workflows/android-apk.yml`.

1. Create a new GitHub repository.
2. Upload **all files and folders inside this ZIP** to the repository root
   (do not upload the ZIP as a single file).
3. Push the files to the `main` or `master` branch.
4. Open the repository's **Actions** tab.
5. Select **Build Android APK** and open the latest successful run.
6. Under **Artifacts**, download `K3OverlayBot-debug-apk`.
7. Extract the artifact ZIP. It contains `app-debug.apk`.

You can also start a build manually from **Actions → Build Android APK →
Run workflow**.

The workflow builds a **debug APK**. It is suitable for testing and local
installation, but it is not a Play Store release build and is not signed
with your own release key.

## Build Android locally

Requirements: JDK 17, Android SDK Platform 35, Android Build Tools 35.0.0,
and Gradle 8.9.

From the repository root, run:

```bash
gradle -p android-app assembleDebug
```

The APK is generated at:

```text
android-app/app/build/outputs/apk/debug/app-debug.apk
```

This project ZIP does not include the Gradle wrapper JAR/scripts. The
included GitHub workflow installs Gradle 8.9 directly, so the CI build does
not depend on a wrapper being present.

## Run the web Studio

Requirements: Node.js compatible with the installed Vite version.

```bash
npm install
npm run dev
```

For a production web build:

```bash
npm run build
```

If a Gemini-backed feature is used, configure the required API key in a
local `.env.local` file according to the app's environment-variable usage.
Never commit API keys or other secrets.

## Important Android permissions

The app declares overlay, foreground-service, notification, and accessibility
capabilities. Android requires the user to grant relevant permissions in
system settings. Accessibility access is powerful: enable it only if you
understand and trust what the service does. Review the code before using it
with sensitive apps or accounts.

## Current verification status

The ZIP has been inspected and GitHub Actions build automation has been
added. An Android APK has **not** been compiled or runtime-tested in this
environment. A successful GitHub Actions run is still required to confirm
that the Android project compiles.
