package com.k3bot.overlay.ocr

import android.graphics.Bitmap
import android.graphics.Rect
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.k3bot.overlay.data.BetTarget
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.math.abs

enum class PopupOutcome {
    WIN,
    LOSS
}

data class HistoryRowResult(
    val periodId: String,
    val sumValue: Int?,
    val outcome: BetTarget?
)

data class OcrToken(
    val text: String,
    val bounds: Rect
)

data class OcrScreenSnapshot(
    val tokens: List<OcrToken>,
    val activePeriod: String?,
    val remainingSeconds: Int?,
    val big2xBounds: Rect?,
    val small2xBounds: Rect?,
    val balanceUnitBounds: Map<Int, Rect>,
    val multiplierChipBounds: Map<Int, Rect>,
    val quantityInputBounds: Rect?,
    val plusButtonBounds: Rect?,
    val iAgreeBounds: Rect?,
    val totalAmountButtonBounds: Rect?,
    val totalAmountRupees: Int?,
    val popupOutcome: PopupOutcome?,
    val popupCloseXBounds: Rect?,
    val gameHistoryHeaderBounds: Rect?,
    val topHistoryRow: HistoryRowResult?
)

class OcrHelper {

    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

    suspend fun analyzeBitmap(bitmap: Bitmap): OcrScreenSnapshot {
        val visionText = recognizeText(bitmap)
        return parseVisionText(visionText, bitmap.width, bitmap.height)
    }

    private suspend fun recognizeText(bitmap: Bitmap): Text? =
        suspendCancellableCoroutine { continuation ->
            val image = InputImage.fromBitmap(bitmap, 0)
            recognizer.process(image)
                .addOnSuccessListener { result ->
                    if (continuation.isActive) continuation.resume(result)
                }
                .addOnFailureListener {
                    if (continuation.isActive) continuation.resume(null)
                }
        }

    fun close() {
        recognizer.close()
    }

    private fun parseVisionText(text: Text?, screenWidth: Int, screenHeight: Int): OcrScreenSnapshot {
        if (text == null) {
            return OcrScreenSnapshot(
                tokens = emptyList(),
                activePeriod = null,
                remainingSeconds = null,
                big2xBounds = null,
                small2xBounds = null,
                balanceUnitBounds = emptyMap(),
                multiplierChipBounds = emptyMap(),
                quantityInputBounds = null,
                plusButtonBounds = null,
                iAgreeBounds = null,
                totalAmountButtonBounds = null,
                totalAmountRupees = null,
                popupOutcome = null,
                popupCloseXBounds = null,
                gameHistoryHeaderBounds = null,
                topHistoryRow = null
            )
        }

        val lines = mutableListOf<OcrToken>()
        val elements = mutableListOf<OcrToken>()

        for (block in text.textBlocks) {
            for (line in block.lines) {
                val box = line.boundingBox ?: continue
                lines.add(OcrToken(line.text.trim(), box))
                for (el in line.elements) {
                    val elBox = el.boundingBox ?: continue
                    elements.add(OcrToken(el.text.trim(), elBox))
                }
            }
        }

        val gameHistoryHeader = lines.firstOrNull {
            it.text.contains("Game history", ignoreCase = true)
        }?.bounds
        val historyCutoffY = gameHistoryHeader?.top ?: Int.MAX_VALUE

        val activePeriod = extractActivePeriod(lines, historyCutoffY)
        val remainingSeconds = extractRemainingSeconds(lines)

        val big2xBounds = findBetOptionBounds(lines, elements, "Big", historyCutoffY)
        val small2xBounds = findBetOptionBounds(lines, elements, "Small", historyCutoffY)

        val balanceUnits = extractBalanceUnits(elements, lines)
        val multiplierChips = extractMultiplierChips(elements, lines)
        val quantityInputBounds = findQuantityInputBounds(lines, elements)
        val plusBounds = findPlusButtonBounds(elements, quantityInputBounds)
        val iAgreeBounds = lines.firstOrNull {
            it.text.contains("I agree", ignoreCase = true)
        }?.bounds

        val totalButtonLine = lines.firstOrNull {
            it.text.contains("Total amount", ignoreCase = true)
        }
        val totalRupees = totalButtonLine?.let { parseRupeesFromTotal(it.text) }

        val popupOutcome = detectPopupOutcome(lines)
        val popupCloseXBounds = if (popupOutcome != null) {
            findPopupCloseXBounds(lines, elements, screenWidth, screenHeight)
        } else {
            null
        }

        val topHistoryRow = extractTopHistoryRow(lines, elements, gameHistoryHeader)

        return OcrScreenSnapshot(
            tokens = lines,
            activePeriod = activePeriod,
            remainingSeconds = remainingSeconds,
            big2xBounds = big2xBounds,
            small2xBounds = small2xBounds,
            balanceUnitBounds = balanceUnits,
            multiplierChipBounds = multiplierChips,
            quantityInputBounds = quantityInputBounds,
            plusButtonBounds = plusBounds,
            iAgreeBounds = iAgreeBounds,
            totalAmountButtonBounds = totalButtonLine?.bounds,
            totalAmountRupees = totalRupees,
            popupOutcome = popupOutcome,
            popupCloseXBounds = popupCloseXBounds,
            gameHistoryHeaderBounds = gameHistoryHeader,
            topHistoryRow = topHistoryRow
        )
    }

    private fun extractActivePeriod(lines: List<OcrToken>, historyCutoffY: Int): String? {
        val periodRegex = Regex("""\b(\d{15,19})\b""")
        val candidates = lines
            .filter { it.bounds.top < historyCutoffY }
            .sortedBy { it.bounds.top }
        for (token in candidates) {
            val match = periodRegex.find(token.text.replace(" ", ""))
            if (match != null) return match.groupValues[1]
        }
        return null
    }

    private fun extractRemainingSeconds(lines: List<OcrToken>): Int? {
        val colonTimerRegex = Regex("""\b(\d{2})\s*[:：]\s*(\d{2})\b""")
        for (line in lines.sortedBy { it.bounds.top }) {
            val match = colonTimerRegex.find(line.text)
            if (match != null) {
                val mins = match.groupValues[1].toIntOrNull() ?: continue
                val secs = match.groupValues[2].toIntOrNull() ?: continue
                if (mins in 0..5 && secs in 0..59) {
                    return mins * 60 + secs
                }
            }
        }
        // Fallback: split digits like "0 0 : 4 5"
        val splitTimerRegex = Regex("""(\d)\s*(\d)\s*[:：]?\s*(\d)\s*(\d)""")
        val timeHeader = lines.firstOrNull {
            it.text.contains("Time remaining", ignoreCase = true)
        }
        if (timeHeader != null) {
            val nearby = lines.filter {
                it.bounds.top >= timeHeader.bounds.top - 20 &&
                    it.bounds.top <= timeHeader.bounds.bottom + 140
            }
            for (line in nearby) {
                val match = splitTimerRegex.find(line.text)
                if (match != null) {
                    val mins = "${match.groupValues[1]}${match.groupValues[2]}".toIntOrNull() ?: continue
                    val secs = "${match.groupValues[3]}${match.groupValues[4]}".toIntOrNull() ?: continue
                    if (mins in 0..5 && secs in 0..59) return mins * 60 + secs
                }
            }
        }
        return null
    }

    private fun findBetOptionBounds(
        lines: List<OcrToken>,
        elements: List<OcrToken>,
        label: String,
        historyCutoffY: Int
    ): Rect? {
        // Direct single line e.g. "Big 2X" or "Small 2X"
        val direct = lines.firstOrNull {
            it.bounds.top < historyCutoffY &&
                it.text.contains(label, ignoreCase = true) &&
                it.text.contains("2X", ignoreCase = true)
        }
        if (direct != null) return direct.bounds

        // Stacked two-line button ("Big" above "2X")
        val labelTokens = elements.filter {
            it.bounds.top < historyCutoffY &&
                it.text.equals(label, ignoreCase = true)
        }
        val twoXTokens = elements.filter {
            it.bounds.top < historyCutoffY &&
                it.text.equals("2X", ignoreCase = true)
        }
        for (lbl in labelTokens) {
            val paired = twoXTokens.firstOrNull {
                abs(it.bounds.centerX() - lbl.bounds.centerX()) < 140 &&
                    it.bounds.top >= lbl.bounds.top - 20 &&
                    it.bounds.top <= lbl.bounds.bottom + 90
            }
            if (paired != null) {
                return Rect(
                    minOf(lbl.bounds.left, paired.bounds.left),
                    lbl.bounds.top,
                    maxOf(lbl.bounds.right, paired.bounds.right),
                    paired.bounds.bottom
                )
            }
        }
        return null
    }

    private fun extractBalanceUnits(
        elements: List<OcrToken>,
        lines: List<OcrToken>
    ): Map<Int, Rect> {
        val balanceHeader = lines.firstOrNull {
            it.text.equals("Balance", ignoreCase = true) ||
                it.text.contains("Balance", ignoreCase = true)
        } ?: return emptyMap()

        val rowTokens = elements.filter {
            abs(it.bounds.centerY() - balanceHeader.bounds.centerY()) < 75 &&
                it.bounds.left >= balanceHeader.bounds.left
        }
        val result = mutableMapOf<Int, Rect>()
        for (token in rowTokens) {
            when (token.text.uppercase()) {
                "1" -> result[1] = token.bounds
                "10" -> result[10] = token.bounds
                "100" -> result[100] = token.bounds
                "1K", "1000" -> result[1000] = token.bounds
            }
        }
        return result
    }

    private fun extractMultiplierChips(
        elements: List<OcrToken>,
        lines: List<OcrToken>
    ): Map<Int, Rect> {
        val multRegex = Regex("""^X(1|5|10|20|50|100)$""", RegexOption.IGNORE_CASE)
        val result = mutableMapOf<Int, Rect>()
        for (token in elements + lines) {
            val match = multRegex.matchEntire(token.text.replace(" ", ""))
            if (match != null) {
                val value = match.groupValues[1].toIntOrNull() ?: continue
                result[value] = token.bounds
            }
        }
        return result
    }

    private fun findQuantityInputBounds(lines: List<OcrToken>, elements: List<OcrToken>): Rect? {
        val qtyLabel = lines.firstOrNull {
            it.text.equals("Quantity", ignoreCase = true)
        } ?: return null

        return elements.firstOrNull {
            abs(it.bounds.centerY() - qtyLabel.bounds.centerY()) < 80 &&
                it.bounds.left > qtyLabel.bounds.right &&
                it.text.all { ch -> ch.isDigit() }
        }?.bounds
    }

    private fun findPlusButtonBounds(elements: List<OcrToken>, qtyBounds: Rect?): Rect? {
        if (qtyBounds == null) return null
        return elements.firstOrNull {
            it.text == "+" &&
                abs(it.bounds.centerY() - qtyBounds.centerY()) < 80 &&
                it.bounds.left > qtyBounds.right - 10
        }?.bounds
    }

    private fun parseRupeesFromTotal(text: String): Int? {
        val match = Regex("""[₹$]?\s*(\d[\d,]*)(?:\.\d{1,2})?""").find(text)
            ?: return null
        return match.groupValues[1].replace(",", "").toIntOrNull()
    }

    private fun detectPopupOutcome(lines: List<OcrToken>): PopupOutcome? {
        if (lines.any { it.text.contains("Congratulations", ignoreCase = true) }) {
            return PopupOutcome.WIN
        }
        if (lines.any {
                it.text.contains("Sorry", ignoreCase = true) ||
                    it.text.contains("Better luck", ignoreCase = true)
            }
        ) {
            return PopupOutcome.LOSS
        }
        return null
    }

    private fun findPopupCloseXBounds(
        lines: List<OcrToken>,
        elements: List<OcrToken>,
        screenWidth: Int,
        screenHeight: Int
    ): Rect? {
        val anchorBottom = lines.firstOrNull {
            it.text.contains("Congratulations", ignoreCase = true) ||
                it.text.contains("Sorry", ignoreCase = true)
        }?.bounds?.bottom ?: (screenHeight / 2)

        val candidates = (elements + lines).filter {
            (it.text.equals("X", ignoreCase = true) || it.text == "×" || it.text == "✕") &&
                it.bounds.top > anchorBottom &&
                abs(it.bounds.centerX() - screenWidth / 2) < screenWidth / 3
        }
        return candidates.maxByOrNull { it.bounds.top }?.bounds
    }

    private fun extractTopHistoryRow(
        lines: List<OcrToken>,
        elements: List<OcrToken>,
        headerBounds: Rect?
    ): HistoryRowResult? {
        val anchorTop = headerBounds?.bottom ?: return null
        val periodRegex = Regex("""\b(\d{15,19})\b""")

        val firstPeriodToken = lines
            .filter { it.bounds.top > anchorTop }
            .sortedBy { it.bounds.top }
            .firstOrNull { periodRegex.containsMatchIn(it.text.replace(" ", "")) }
            ?: return null

        val periodId = periodRegex.find(firstPeriodToken.text.replace(" ", ""))?.groupValues?.get(1)
            ?: return null

        val rowY = firstPeriodToken.bounds.centerY()
        val rowTokens = (lines + elements).filter {
            abs(it.bounds.centerY() - rowY) < 48
        }

        val outcome = when {
            rowTokens.any { it.text.equals("Big", ignoreCase = true) } -> BetTarget.BIG
            rowTokens.any { it.text.equals("Small", ignoreCase = true) } -> BetTarget.SMALL
            else -> null
        }

        val sumValue = rowTokens
            .mapNotNull { it.text.toIntOrNull() }
            .firstOrNull { it in 3..18 }

        return HistoryRowResult(
            periodId = periodId,
            sumValue = sumValue,
            outcome = outcome
        )
    }
}
