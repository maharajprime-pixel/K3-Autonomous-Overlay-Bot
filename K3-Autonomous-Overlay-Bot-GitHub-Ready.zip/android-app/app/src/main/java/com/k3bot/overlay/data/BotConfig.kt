package com.k3bot.overlay.data

import android.graphics.Rect
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

enum class BetTarget(val label: String, val buttonLabel: String) {
    BIG("Big", "Big 2X"),
    SMALL("Small", "Small 2X");

    fun toggled(): BetTarget = if (this == BIG) SMALL else BIG
}

enum class BotState(val displayText: String) {
    IDLE("IDLE"),
    WAITING_FOR_NEXT_ROUND("WAITING FOR NEXT ROUND"),
    PLACING_BET("PLACING BET"),
    VERIFYING_RESULT("VERIFYING RESULT"),
    STOPPED_LEVEL_15_LIMIT("STOPPED - LEVEL 15 LIMIT REACHED"),
    STOPPED_UI_ERROR("STOPPED - UI ERROR");

    val isStoppedError: Boolean
        get() = this == STOPPED_LEVEL_15_LIMIT || this == STOPPED_UI_ERROR
}

sealed class BotCommand {
    data object Start : BotCommand()
    data object Stop : BotCommand()
    data object ConfigUpdated : BotCommand()
}

data class BotTelemetry(
    val state: BotState = BotState.IDLE,
    val detailMessage: String = "Ready",
    val currentPeriod: String = "—",
    val remainingSeconds: Int = -1,
    val currentLevel: Int = 1,
    val currentAmount: Int = 10,
    val lastBetPeriod: String? = null,
    val target: BetTarget = BetTarget.BIG,
    val isRunning: Boolean = false
)

object BotCoordinator {
    private val _telemetry = MutableStateFlow(BotTelemetry())
    val telemetry: StateFlow<BotTelemetry> = _telemetry.asStateFlow()

    private val _commands = MutableSharedFlow<BotCommand>(extraBufferCapacity = 16)
    val commands: SharedFlow<BotCommand> = _commands.asSharedFlow()

    @Volatile
    var overlayBounds: Rect = Rect(0, 0, 0, 0)

    @Volatile
    var isAccessibilityConnected: Boolean = false

    fun updateTelemetry(transform: (BotTelemetry) -> BotTelemetry) {
        _telemetry.update(transform)
    }

    fun sendCommand(command: BotCommand) {
        _commands.tryEmit(command)
    }
}
