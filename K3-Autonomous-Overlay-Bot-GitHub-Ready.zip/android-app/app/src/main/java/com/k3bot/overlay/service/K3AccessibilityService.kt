package com.k3bot.overlay.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Bitmap
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.view.Display
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.k3bot.overlay.data.BetTarget
import com.k3bot.overlay.data.BotCommand
import com.k3bot.overlay.data.BotCoordinator
import com.k3bot.overlay.data.BotState
import com.k3bot.overlay.data.PrefsManager
import com.k3bot.overlay.ocr.HistoryRowResult
import com.k3bot.overlay.ocr.OcrHelper
import com.k3bot.overlay.ocr.OcrScreenSnapshot
import com.k3bot.overlay.ocr.PopupOutcome
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import java.util.concurrent.Executors
import kotlin.coroutines.resume
import kotlin.math.abs

class K3AccessibilityService : AccessibilityService() {

    private val serviceScope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    private val screenshotExecutor = Executors.newSingleThreadExecutor()

    private lateinit var prefsManager: PrefsManager
    private lateinit var ocrHelper: OcrHelper

    private var automationJob: Job? = null
    private var isRunning = false
    private var currentLevel = 1
    private var lastBetPeriod: String? = null
    private var pendingVerificationPeriod: String? = null

    private data class NodeItem(
        val node: AccessibilityNodeInfo,
        val text: String,
        val bounds: Rect,
        val isEditable: Boolean,
        val isClickable: Boolean,
        val isChecked: Boolean
    )

    private data class HybridScreenState(
        val nodes: List<NodeItem>,
        val ocr: OcrScreenSnapshot?,
        val screenWidth: Int,
        val screenHeight: Int,
        val activePeriod: String?,
        val remainingSeconds: Int?,
        val big2xBounds: Rect?,
        val small2xBounds: Rect?,
        val popupOutcome: PopupOutcome?,
        val popupCloseXBounds: Rect?,
        val gameHistoryHeaderBounds: Rect?,
        val topHistoryRow: HistoryRowResult?
    )

    private data class FallbackTapPlan(
        val baseUnit: Int,
        val multiplierChip: Int,
        val plusTaps: Int
    )

    override fun onServiceConnected() {
        super.onServiceConnected()
        prefsManager = PrefsManager(this)
        ocrHelper = OcrHelper()
        BotCoordinator.isAccessibilityConnected = true

        serviceScope.launch {
            BotCoordinator.commands.collectLatest { command ->
                when (command) {
                    is BotCommand.Start -> startAutomation()
                    is BotCommand.Stop -> stopAutomation(BotState.IDLE, "Stopped by user")
                    is BotCommand.ConfigUpdated -> syncCurrentLevelTelemetry()
                }
            }
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Primary state machine runs on a deterministic 500ms coroutine loop;
        // events keep the window tree fresh.
    }

    override fun onInterrupt() {
        stopAutomation(BotState.IDLE, "Service interrupted")
    }

    override fun onDestroy() {
        super.onDestroy()
        BotCoordinator.isAccessibilityConnected = false
        automationJob?.cancel()
        serviceScope.cancel()
        screenshotExecutor.shutdownNow()
        if (::ocrHelper.isInitialized) {
            ocrHelper.close()
        }
    }

    private fun startAutomation() {
        if (isRunning) return
        isRunning = true
        currentLevel = BotCoordinator.telemetry.value.currentLevel.coerceIn(1, PrefsManager.MAX_LEVELS)
        syncCurrentLevelTelemetry()

        BotCoordinator.updateTelemetry {
            it.copy(
                isRunning = true,
                state = BotState.WAITING_FOR_NEXT_ROUND,
                detailMessage = "Scanning active round..."
            )
        }

        automationJob?.cancel()
        automationJob = serviceScope.launch {
            while (isActive && isRunning) {
                try {
                    runStateMachineTick()
                } catch (e: Exception) {
                    stopWithUiError("Unexpected automation error: ${e.message ?: "unknown"}")
                }
                delay(POLL_INTERVAL_MS)
            }
        }
    }

    private fun stopAutomation(state: BotState, detail: String) {
        isRunning = false
        automationJob?.cancel()
        automationJob = null
        BotCoordinator.updateTelemetry {
            it.copy(
                isRunning = false,
                state = state,
                detailMessage = detail
            )
        }
    }

    private fun stopWithUiError(reason: String) {
        stopAutomation(BotState.STOPPED_UI_ERROR, reason)
    }

    private fun syncCurrentLevelTelemetry() {
        val target = prefsManager.getTarget()
        val amount = prefsManager.getAmountForLevel(currentLevel)
        BotCoordinator.updateTelemetry {
            it.copy(
                target = target,
                currentLevel = currentLevel,
                currentAmount = amount
            )
        }
    }

    private suspend fun runStateMachineTick() {
        val screen = captureHybridScreen(includeOcr = true)

        // Intercept any win/loss popup overlay immediately if visible
        if (screen.popupOutcome != null) {
            dismissResultPopupIfPresent(screen)
            return
        }

        val period = screen.activePeriod
        val remaining = screen.remainingSeconds

        if (period == null || remaining == null) {
            val retryScreen = captureWithRetries(maxAttempts = 2) { snap ->
                snap.activePeriod != null && snap.remainingSeconds != null
            }
            if (retryScreen == null) {
                stopWithUiError("Unable to locate Period or Time remaining after 2 retries")
                return
            }
            processRoundState(retryScreen)
            return
        }

        processRoundState(screen)
    }

    private suspend fun processRoundState(screen: HybridScreenState) {
        val currentPeriod = screen.activePeriod ?: return
        val remainingSeconds = screen.remainingSeconds ?: return

        BotCoordinator.updateTelemetry {
            it.copy(
                currentPeriod = currentPeriod,
                remainingSeconds = remainingSeconds
            )
        }

        // Phase D: Verify previous bet once the period transitions
        val pendingPeriod = pendingVerificationPeriod
        if (pendingPeriod != null && currentPeriod != pendingPeriod) {
            executePhaseDResultVerification(pendingPeriod)
            return
        }

        // Already bet on this round: wait cleanly for transition
        if (currentPeriod == lastBetPeriod) {
            BotCoordinator.updateTelemetry {
                it.copy(
                    state = BotState.WAITING_FOR_NEXT_ROUND,
                    detailMessage = "Bet active on $currentPeriod (${remainingSeconds}s left)"
                )
            }
            return
        }

        // Phase A Timer Buffer Rule: never click during the final 10 seconds (00:00 - 00:09)
        if (remainingSeconds < MIN_SAFE_SECONDS) {
            BotCoordinator.updateTelemetry {
                it.copy(
                    state = BotState.WAITING_FOR_NEXT_ROUND,
                    detailMessage = "Buffer lock (<10s): waiting for next round"
                )
            }
            return
        }

        // Phase B + Phase C: Place bet for currentPeriod
        val target = prefsManager.getTarget()
        val levelAmount = prefsManager.getAmountForLevel(currentLevel)

        BotCoordinator.updateTelemetry {
            it.copy(
                state = BotState.PLACING_BET,
                detailMessage = "Phase B: Locating ${target.buttonLabel}"
            )
        }

        val clickedBetButton = executePhaseBSmartScrollAndTap(target)
        if (!clickedBetButton) {
            stopWithUiError("Failed to locate or tap ${target.buttonLabel} after 2 retries")
            return
        }

        val modalConfirmed = executePhaseCAmountModal(levelAmount)
        if (!modalConfirmed) {
            return // Error state already set inside Phase C
        }

        lastBetPeriod = currentPeriod
        pendingVerificationPeriod = currentPeriod
        BotCoordinator.updateTelemetry {
            it.copy(
                lastBetPeriod = currentPeriod,
                state = BotState.WAITING_FOR_NEXT_ROUND,
                detailMessage = "Placed ₹$levelAmount on ${target.label} ($currentPeriod)"
            )
        }
    }

    /**
     * Phase B: Smart Vertical Scroll & Viewport Anchoring
     */
    private suspend fun executePhaseBSmartScrollAndTap(target: BetTarget): Boolean {
        for (attempt in 1..MAX_UI_RETRIES + 1) {
            if (!isRunning) return false
            val screen = captureHybridScreen(includeOcr = true)
            val bounds = if (target == BetTarget.BIG) screen.big2xBounds else screen.small2xBounds

            if (bounds == null) {
                // Scroll gently upward/downward to bring Total Big/Small buttons into view
                val scrollDown = attempt == 1
                performVerticalScrollGesture(
                    screenWidth = screen.screenWidth,
                    screenHeight = screen.screenHeight,
                    scrollDown = scrollDown,
                    distanceFraction = 0.28f
                )
                delay(SCROLL_SETTLE_MS)
                continue
            }

            val middleTop = (screen.screenHeight * 0.25f).toInt()
            val middleBottom = (screen.screenHeight * 0.75f).toInt()
            val overlapsOverlay = Rect.intersects(bounds, BotCoordinator.overlayBounds)
            val isOutsideMiddleViewport =
                bounds.top < middleTop || bounds.bottom > middleBottom

            if (isOutsideMiddleViewport || overlapsOverlay) {
                val scrollDown = bounds.centerY() > screen.screenHeight / 2
                val deltaPx = abs(bounds.centerY() - screen.screenHeight / 2)
                    .coerceIn(140, (screen.screenHeight * 0.35f).toInt())
                performVerticalScrollGesture(
                    screenWidth = screen.screenWidth,
                    screenHeight = screen.screenHeight,
                    scrollDown = scrollDown,
                    distancePx = deltaPx
                )
                delay(SCROLL_SETTLE_MS)

                val settledScreen = captureHybridScreen(includeOcr = true)
                val settledBounds =
                    if (target == BetTarget.BIG) settledScreen.big2xBounds else settledScreen.small2xBounds
                if (settledBounds != null &&
                    settledBounds.top >= 0 &&
                    settledBounds.bottom <= settledScreen.screenHeight &&
                    !Rect.intersects(settledBounds, BotCoordinator.overlayBounds)
                ) {
                    return tapCenter(settledBounds)
                }
            } else {
                return tapCenter(bounds)
            }
        }
        return false
    }

    /**
     * Phase C: Amount Popup Modal Execution
     */
    private suspend fun executePhaseCAmountModal(targetAmount: Int): Boolean {
        delay(450L)

        // Wait for modal to appear (up to 2 retries)
        val modalScreen = captureWithRetries(maxAttempts = MAX_UI_RETRIES + 1) { snap ->
            val ocr = snap.ocr
            val hasTotal = snap.nodes.any { it.text.contains("Total amount", ignoreCase = true) } ||
                ocr?.totalAmountButtonBounds != null
            val hasQty = snap.nodes.any { it.text.equals("Quantity", ignoreCase = true) } ||
                ocr?.quantityInputBounds != null
            hasTotal && hasQty
        }

        if (modalScreen == null) {
            stopWithUiError("Bet amount popup modal did not open after tapping target")
            return false
        }

        // 1. Select Base Unit '1' in Balance row so 1 * Quantity = exact rupee amount
        val base1Bounds = findBalanceUnitNode(modalScreen, "1")?.bounds
            ?: modalScreen.ocr?.balanceUnitBounds?.get(1)
        if (base1Bounds == null) {
            stopWithUiError("Balance unit '1' button missing in popup modal")
            return false
        }
        if (!tapCenter(base1Bounds)) {
            stopWithUiError("Failed to tap Balance unit '1'")
            return false
        }
        delay(220L)

        // 2. Clear & inject exact integer amount into Quantity input
        val refreshed = captureHybridScreen(includeOcr = true)
        val qtyInjected = injectQuantityOrFallback(refreshed, targetAmount)
        if (!qtyInjected) {
            stopWithUiError("Failed to set Quantity to ₹$targetAmount")
            return false
        }
        delay(280L)

        // 3. Verify 'I agree' checkbox is checked
        val agreeScreen = captureHybridScreen(includeOcr = true)
        val agreeNode = agreeScreen.nodes.firstOrNull {
            it.text.contains("I agree", ignoreCase = true)
        }
        if (agreeNode != null && !agreeNode.isChecked) {
            tapCenter(agreeNode.bounds)
            delay(200L)
        } else if (agreeNode == null && agreeScreen.ocr?.iAgreeBounds != null) {
            // Confirm visually if OCR sees it unchecked only if needed; default in K3 is checked
        }

        // 4. Pre-Submit Amount Verification & Confirmation
        val verifyScreen = captureHybridScreen(includeOcr = true)
        val totalNode = verifyScreen.nodes.firstOrNull {
            it.text.contains("Total amount", ignoreCase = true)
        }
        val totalBounds = totalNode?.bounds ?: verifyScreen.ocr?.totalAmountButtonBounds
        val displayedRupees = totalNode?.let { parseRupees(it.text) }
            ?: verifyScreen.ocr?.totalAmountRupees

        if (totalBounds == null || displayedRupees == null) {
            stopWithUiError("Could not read Total amount confirmation button")
            return false
        }

        if (displayedRupees != targetAmount) {
            stopWithUiError(
                "Amount mismatch: expected ₹$targetAmount, modal shows ₹$displayedRupees"
            )
            return false
        }

        if (!tapCenter(totalBounds)) {
            stopWithUiError("Failed to tap Total amount confirmation button")
            return false
        }
        delay(450L)
        return true
    }

    private suspend fun injectQuantityOrFallback(
        screen: HybridScreenState,
        targetAmount: Int
    ): Boolean {
        val editableNode = findQuantityEditableNode(screen)
        if (editableNode != null) {
            editableNode.node.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
            delay(100L)
            val clearArgs = Bundle().apply {
                putCharSequence(
                    AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,
                    ""
                )
            }
            editableNode.node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, clearArgs)
            delay(100L)

            val setArgs = Bundle().apply {
                putCharSequence(
                    AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,
                    targetAmount.toString()
                )
            }
            val setOk = editableNode.node.performAction(
                AccessibilityNodeInfo.ACTION_SET_TEXT,
                setArgs
            )
            delay(220L)

            if (setOk) {
                val postCheck = captureHybridScreen(includeOcr = true)
                val postTotal = postCheck.nodes
                    .firstOrNull { it.text.contains("Total amount", ignoreCase = true) }
                    ?.let { parseRupees(it.text) }
                    ?: postCheck.ocr?.totalAmountRupees
                if (postTotal == targetAmount) {
                    return true
                }
            }
        }

        // Fallback: compute exact combination of Base Units (1, 10, 100, 1K),
        // Multiplier chips (X1, X5, X10, X20, X50, X100), and '+' button taps.
        val plan = buildFallbackAmountPlan(targetAmount) ?: return false
        val ocr = screen.ocr

        val unitBounds = findBalanceUnitNode(screen, unitLabel(plan.baseUnit))?.bounds
            ?: ocr?.balanceUnitBounds?.get(plan.baseUnit)
            ?: return false
        if (!tapCenter(unitBounds)) return false
        delay(180L)

        val multBounds = findMultiplierChipNode(screen, plan.multiplierChip)?.bounds
            ?: ocr?.multiplierChipBounds?.get(plan.multiplierChip)
            ?: return false
        if (!tapCenter(multBounds)) return false
        delay(180L)

        if (plan.plusTaps > 0) {
            val plusBounds = findPlusButtonNode(screen)?.bounds
                ?: ocr?.plusButtonBounds
                ?: return false
            repeat(plan.plusTaps) {
                if (!isRunning) return false
                tapCenter(plusBounds)
                delay(120L)
            }
        }
        return true
    }

    /**
     * Phase D: Result Detection, Popup Dismissal & 15-Level Progression
     */
    private suspend fun executePhaseDResultVerification(betPeriod: String) {
        BotCoordinator.updateTelemetry {
            it.copy(
                state = BotState.VERIFYING_RESULT,
                detailMessage = "Phase D: Verifying round $betPeriod"
            )
        }

        // 1. Intercept & dismiss Win/Loss popup overlay if shown
        val initialScreen = captureHybridScreen(includeOcr = true)
        if (initialScreen.popupOutcome != null) {
            dismissResultPopupIfPresent(initialScreen)
        }

        // 2. Ensure Game history table is visible & inspect top row matching betPeriod
        var matchedRow: HistoryRowResult? = null
        var scrolledForHistory = false

        for (attempt in 1..MAX_UI_RETRIES + 2) {
            if (!isRunning) return
            val snap = captureHybridScreen(includeOcr = true)

            if (snap.popupOutcome != null) {
                dismissResultPopupIfPresent(snap)
                continue
            }

            val row = snap.topHistoryRow
            if (row != null && row.periodId == betPeriod && row.outcome != null) {
                matchedRow = row
                break
            }

            if (snap.gameHistoryHeaderBounds == null || snap.topHistoryRow == null) {
                performVerticalScrollGesture(
                    screenWidth = snap.screenWidth,
                    screenHeight = snap.screenHeight,
                    scrollDown = true,
                    distanceFraction = 0.25f
                )
                scrolledForHistory = true
                delay(SCROLL_SETTLE_MS)
            } else {
                // History is visible but latest period row may still be settling
                delay(650L)
            }
        }

        // Scroll back up if we scrolled down to view Game history
        if (scrolledForHistory) {
            val current = captureHybridScreen(includeOcr = false)
            performVerticalScrollGesture(
                screenWidth = current.screenWidth,
                screenHeight = current.screenHeight,
                scrollDown = false,
                distanceFraction = 0.25f
            )
            delay(SCROLL_SETTLE_MS)
        }

        val verifiedRow = matchedRow
        if (verifiedRow == null || verifiedRow.outcome == null) {
            stopWithUiError("Game history row for $betPeriod not found after retries")
            return
        }

        // 3. Progression Update
        val target = prefsManager.getTarget()
        val won = verifiedRow.outcome == target
        pendingVerificationPeriod = null

        if (won) {
            currentLevel = 1
            val level1Amount = prefsManager.getAmountForLevel(1)
            BotCoordinator.updateTelemetry {
                it.copy(
                    currentLevel = 1,
                    currentAmount = level1Amount,
                    state = BotState.WAITING_FOR_NEXT_ROUND,
                    detailMessage = "WIN ($betPeriod: ${verifiedRow.outcome.label}) -> Reset to Level 1"
                )
            }
        } else {
            if (currentLevel >= PrefsManager.MAX_LEVELS) {
                // Mandatory Level 15 Hard Stop
                stopAutomation(
                    BotState.STOPPED_LEVEL_15_LIMIT,
                    "Loss on Level 15 ($betPeriod: ${verifiedRow.outcome.label}). Hard stop triggered."
                )
                return
            }

            currentLevel += 1
            val nextAmount = prefsManager.getAmountForLevel(currentLevel)
            BotCoordinator.updateTelemetry {
                it.copy(
                    currentLevel = currentLevel,
                    currentAmount = nextAmount,
                    state = BotState.WAITING_FOR_NEXT_ROUND,
                    detailMessage = "LOSS ($betPeriod: ${verifiedRow.outcome.label}) -> Level $currentLevel (₹$nextAmount)"
                )
            }
        }
    }

    private suspend fun dismissResultPopupIfPresent(screen: HybridScreenState) {
        val closeBounds = screen.popupCloseXBounds
        if (closeBounds != null) {
            tapCenter(closeBounds)
            delay(POPUP_DISMISS_WAIT_MS)
        } else {
            // Secondary lookup in node tree for close button beneath popup
            val fallbackX = screen.nodes.firstOrNull {
                it.text.equals("X", ignoreCase = true) ||
                    it.text == "×" ||
                    it.text == "✕"
            }?.bounds
            if (fallbackX != null) {
                tapCenter(fallbackX)
                delay(POPUP_DISMISS_WAIT_MS)
            }
        }
    }

    private suspend fun captureWithRetries(
        maxAttempts: Int,
        predicate: (HybridScreenState) -> Boolean
    ): HybridScreenState? {
        repeat(maxAttempts) {
            if (!isRunning) return null
            val snap = captureHybridScreen(includeOcr = true)
            if (predicate(snap)) return snap
            delay(350L)
        }
        return null
    }

    private suspend fun captureHybridScreen(includeOcr: Boolean): HybridScreenState {
        val metrics = resources.displayMetrics
        val screenWidth = metrics.widthPixels
        val screenHeight = metrics.heightPixels

        val root = rootInActiveWindow
        val nodes = if (root != null) collectNodes(root) else emptyList()

        val ocrSnapshot = if (includeOcr && Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val bitmap = takeScreenshotBitmap()
            if (bitmap != null) {
                try {
                    ocrHelper.analyzeBitmap(bitmap)
                } finally {
                    bitmap.recycle()
                }
            } else {
                null
            }
        } else {
            null
        }

        val activePeriod = extractPeriodFromNodes(nodes) ?: ocrSnapshot?.activePeriod
        val remainingSeconds = extractRemainingSecondsFromNodes(nodes) ?: ocrSnapshot?.remainingSeconds
        val big2xBounds = findBetButtonNodeBounds(nodes, "Big") ?: ocrSnapshot?.big2xBounds
        val small2xBounds = findBetButtonNodeBounds(nodes, "Small") ?: ocrSnapshot?.small2xBounds

        val popupOutcome = detectPopupOutcomeFromNodes(nodes) ?: ocrSnapshot?.popupOutcome
        val popupCloseX = ocrSnapshot?.popupCloseXBounds
            ?: if (popupOutcome != null) {
                nodes.lastOrNull {
                    it.text.equals("X", ignoreCase = true) || it.text == "×" || it.text == "✕"
                }?.bounds
            } else {
                null
            }

        val historyHeaderBounds = nodes.firstOrNull {
            it.text.contains("Game history", ignoreCase = true)
        }?.bounds ?: ocrSnapshot?.gameHistoryHeaderBounds

        val topHistoryRow = extractTopHistoryRowFromNodes(nodes, historyHeaderBounds)
            ?: ocrSnapshot?.topHistoryRow

        return HybridScreenState(
            nodes = nodes,
            ocr = ocrSnapshot,
            screenWidth = screenWidth,
            screenHeight = screenHeight,
            activePeriod = activePeriod,
            remainingSeconds = remainingSeconds,
            big2xBounds = big2xBounds,
            small2xBounds = small2xBounds,
            popupOutcome = popupOutcome,
            popupCloseXBounds = popupCloseX,
            gameHistoryHeaderBounds = historyHeaderBounds,
            topHistoryRow = topHistoryRow
        )
    }

    private suspend fun takeScreenshotBitmap(): Bitmap? {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) return null
        return suspendCancellableCoroutine { continuation ->
            takeScreenshot(
                Display.DEFAULT_DISPLAY,
                screenshotExecutor,
                object : TakeScreenshotCallback {
                    override fun onSuccess(screenshot: ScreenshotResult) {
                        val hwBuffer = screenshot.hardwareBuffer
                        val wrapped = Bitmap.wrapHardwareBuffer(hwBuffer, screenshot.colorSpace)
                        val software = wrapped?.copy(Bitmap.Config.ARGB_8888, false)
                        wrapped?.recycle()
                        hwBuffer.close()
                        if (continuation.isActive) continuation.resume(software)
                    }

                    override fun onFailure(errorCode: Int) {
                        if (continuation.isActive) continuation.resume(null)
                    }
                }
            )
        }
    }

    private fun collectNodes(root: AccessibilityNodeInfo): List<NodeItem> {
        val result = mutableListOf<NodeItem>()
        val stack = ArrayDeque<AccessibilityNodeInfo>()
        stack.addLast(root)

        while (stack.isNotEmpty()) {
            val node = stack.removeLast()
            val text = (node.text?.toString() ?: node.contentDescription?.toString() ?: "").trim()
            val rect = Rect()
            node.getBoundsInScreen(rect)

            if (rect.width() > 0 && rect.height() > 0) {
                result.add(
                    NodeItem(
                        node = node,
                        text = text,
                        bounds = rect,
                        isEditable = node.isEditable,
                        isClickable = node.isClickable,
                        isChecked = node.isChecked || node.isSelected
                    )
                )
            }

            for (i in 0 until node.childCount) {
                node.getChild(i)?.let { stack.addLast(it) }
            }
        }
        return result
    }

    private fun extractPeriodFromNodes(nodes: List<NodeItem>): String? {
        val historyTop = nodes.firstOrNull {
            it.text.contains("Game history", ignoreCase = true)
        }?.bounds?.top ?: Int.MAX_VALUE

        val regex = Regex("""\b(\d{15,19})\b""")
        return nodes
            .filter { it.bounds.top < historyTop && it.text.isNotEmpty() }
            .sortedBy { it.bounds.top }
            .firstNotNullOfOrNull { regex.find(it.text.replace(" ", ""))?.groupValues?.get(1) }
    }

    private fun extractRemainingSecondsFromNodes(nodes: List<NodeItem>): Int? {
        val regex = Regex("""\b(\d{2})\s*[:：]\s*(\d{2})\b""")
        for (node in nodes.sortedBy { it.bounds.top }) {
            val match = regex.find(node.text) ?: continue
            val m = match.groupValues[1].toIntOrNull() ?: continue
            val s = match.groupValues[2].toIntOrNull() ?: continue
            if (m in 0..5 && s in 0..59) return m * 60 + s
        }
        return null
    }

    private fun findBetButtonNodeBounds(nodes: List<NodeItem>, label: String): Rect? {
        val historyTop = nodes.firstOrNull {
            it.text.contains("Game history", ignoreCase = true)
        }?.bounds?.top ?: Int.MAX_VALUE

        return nodes.firstOrNull {
            it.bounds.top < historyTop &&
                it.text.contains(label, ignoreCase = true) &&
                it.text.contains("2X", ignoreCase = true)
        }?.bounds
    }

    private fun findBalanceUnitNode(screen: HybridScreenState, label: String): NodeItem? {
        val balanceHeader = screen.nodes.firstOrNull {
            it.text.equals("Balance", ignoreCase = true)
        } ?: return null

        return screen.nodes.firstOrNull {
            it.text.equals(label, ignoreCase = true) &&
                abs(it.bounds.centerY() - balanceHeader.bounds.centerY()) < 90 &&
                it.bounds.left >= balanceHeader.bounds.left
        }
    }

    private fun findMultiplierChipNode(screen: HybridScreenState, multiplier: Int): NodeItem? {
        val expected = "X$multiplier"
        return screen.nodes.firstOrNull {
            it.text.replace(" ", "").equals(expected, ignoreCase = true)
        }
    }

    private fun findQuantityEditableNode(screen: HybridScreenState): NodeItem? {
        val qtyLabel = screen.nodes.firstOrNull {
            it.text.equals("Quantity", ignoreCase = true)
        }
        if (qtyLabel != null) {
            val nearEditable = screen.nodes.firstOrNull {
                it.isEditable && abs(it.bounds.centerY() - qtyLabel.bounds.centerY()) < 100
            }
            if (nearEditable != null) return nearEditable
        }
        return screen.nodes.firstOrNull { it.isEditable }
    }

    private fun findPlusButtonNode(screen: HybridScreenState): NodeItem? {
        val qtyLabel = screen.nodes.firstOrNull {
            it.text.equals("Quantity", ignoreCase = true)
        } ?: return null
        return screen.nodes.firstOrNull {
            it.text == "+" && abs(it.bounds.centerY() - qtyLabel.bounds.centerY()) < 100
        }
    }

    private fun detectPopupOutcomeFromNodes(nodes: List<NodeItem>): PopupOutcome? {
        return when {
            nodes.any { it.text.contains("Congratulations", ignoreCase = true) } -> PopupOutcome.WIN
            nodes.any {
                it.text.contains("Sorry", ignoreCase = true) ||
                    it.text.contains("Better luck", ignoreCase = true)
            } -> PopupOutcome.LOSS
            else -> null
        }
    }

    private fun extractTopHistoryRowFromNodes(
        nodes: List<NodeItem>,
        headerBounds: Rect?
    ): HistoryRowResult? {
        val anchorTop = headerBounds?.bottom ?: return null
        val regex = Regex("""\b(\d{15,19})\b""")
        val firstPeriod = nodes
            .filter { it.bounds.top > anchorTop }
            .sortedBy { it.bounds.top }
            .firstOrNull { regex.containsMatchIn(it.text.replace(" ", "")) }
            ?: return null

        val periodId = regex.find(firstPeriod.text.replace(" ", ""))?.groupValues?.get(1)
            ?: return null
        val rowY = firstPeriod.bounds.centerY()
        val rowNodes = nodes.filter { abs(it.bounds.centerY() - rowY) < 48 }

        val outcome = when {
            rowNodes.any { it.text.equals("Big", ignoreCase = true) } -> BetTarget.BIG
            rowNodes.any { it.text.equals("Small", ignoreCase = true) } -> BetTarget.SMALL
            else -> null
        }
        val sum = rowNodes.mapNotNull { it.text.toIntOrNull() }.firstOrNull { it in 3..18 }

        return HistoryRowResult(periodId, sum, outcome)
    }

    private fun parseRupees(text: String): Int? {
        val match = Regex("""[₹$]?\s*(\d[\d,]*)(?:\.\d{1,2})?""").find(text) ?: return null
        return match.groupValues[1].replace(",", "").toIntOrNull()
    }

    private fun unitLabel(unit: Int): String = if (unit == 1000) "1K" else unit.toString()

    /**
     * Computes exact tap plan using Base Units (1, 10, 100, 1K),
     * Multiplier chips (X1, X5, X10, X20, X50, X100), and '+' taps.
     */
    private fun buildFallbackAmountPlan(targetAmount: Int): FallbackTapPlan? {
        if (targetAmount < 1) return null
        val units = listOf(1000, 100, 10, 1)
        val multipliers = listOf(100, 50, 20, 10, 5, 1)

        var bestPlan: FallbackTapPlan? = null
        var bestTapCost = Int.MAX_VALUE

        for (unit in units) {
            if (targetAmount % unit != 0) continue
            val qtyNeeded = targetAmount / unit
            for (mult in multipliers) {
                if (mult <= qtyNeeded) {
                    val plusTaps = qtyNeeded - mult
                    if (plusTaps in 0..30 && plusTaps < bestTapCost) {
                        bestTapCost = plusTaps
                        bestPlan = FallbackTapPlan(unit, mult, plusTaps)
                    }
                }
            }
        }

        // If targetAmount isn't cleanly reachable within 30 '+' taps using higher units,
        // find closest Base 1 + Multiplier <= targetAmount
        if (bestPlan == null) {
            val mult = multipliers.firstOrNull { it <= targetAmount } ?: 1
            bestPlan = FallbackTapPlan(1, mult, targetAmount - mult)
        }
        return bestPlan
    }

    private suspend fun tapCenter(rect: Rect): Boolean {
        return dispatchTapGesture(rect.centerX().toFloat(), rect.centerY().toFloat())
    }

    private suspend fun dispatchTapGesture(x: Float, y: Float): Boolean =
        suspendCancellableCoroutine { continuation ->
            val path = Path().apply { moveTo(x, y) }
            val stroke = GestureDescription.StrokeDescription(path, 0L, 65L)
            val gesture = GestureDescription.Builder().addStroke(stroke).build()

            val dispatched = dispatchGesture(
                gesture,
                object : GestureResultCallback() {
                    override fun onCompleted(gestureDescription: GestureDescription?) {
                        if (continuation.isActive) continuation.resume(true)
                    }

                    override fun onCancelled(gestureDescription: GestureDescription?) {
                        if (continuation.isActive) continuation.resume(false)
                    }
                },
                null
            )
            if (!dispatched && continuation.isActive) {
                continuation.resume(false)
            }
        }

    private suspend fun performVerticalScrollGesture(
        screenWidth: Int,
        screenHeight: Int,
        scrollDown: Boolean,
        distanceFraction: Float = 0.28f,
        distancePx: Int? = null
    ): Boolean = suspendCancellableCoroutine { continuation ->
        val x = screenWidth * 0.5f
        val delta = (distancePx ?: (screenHeight * distanceFraction).toInt())
            .coerceIn(120, (screenHeight * 0.45f).toInt())
        val startY = if (scrollDown) screenHeight * 0.65f else screenHeight * 0.35f
        val endY = if (scrollDown) {
            (startY - delta).coerceAtLeast(screenHeight * 0.15f)
        } else {
            (startY + delta).coerceAtMost(screenHeight * 0.85f)
        }

        val path = Path().apply {
            moveTo(x, startY)
            lineTo(x, endY)
        }
        val stroke = GestureDescription.StrokeDescription(path, 0L, 260L)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()

        val dispatched = dispatchGesture(
            gesture,
            object : GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) {
                    if (continuation.isActive) continuation.resume(true)
                }

                override fun onCancelled(gestureDescription: GestureDescription?) {
                    if (continuation.isActive) continuation.resume(false)
                }
            },
            null
        )
        if (!dispatched && continuation.isActive) {
            continuation.resume(false)
        }
    }

    companion object {
        private const val POLL_INTERVAL_MS = 500L
        private const val SCROLL_SETTLE_MS = 400L
        private const val POPUP_DISMISS_WAIT_MS = 500L
        private const val MIN_SAFE_SECONDS = 10
        private const val MAX_UI_RETRIES = 2
    }
}
