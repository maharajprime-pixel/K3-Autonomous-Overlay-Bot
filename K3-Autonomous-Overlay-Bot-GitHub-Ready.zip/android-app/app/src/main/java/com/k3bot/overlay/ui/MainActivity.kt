package com.k3bot.overlay.ui

import android.Manifest
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.TextUtils
import android.view.LayoutInflater
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.k3bot.overlay.R
import com.k3bot.overlay.data.BetTarget
import com.k3bot.overlay.data.PrefsManager
import com.k3bot.overlay.databinding.ActivityMainBinding
import com.k3bot.overlay.service.K3AccessibilityService
import com.k3bot.overlay.service.OverlayService

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var prefsManager: PrefsManager
    private val levelEditTexts = mutableListOf<EditText>()

    private val notificationPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { _ ->
            startOverlayAndMinimize()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        prefsManager = PrefsManager(this)
        buildLevelInputs()
        loadSavedConfiguration()
        bindListeners()
    }

    override fun onResume() {
        super.onResume()
        refreshPermissionBadges()
    }

    private fun buildLevelInputs() {
        val inflater = LayoutInflater.from(this)
        binding.levelsContainer.removeAllViews()
        levelEditTexts.clear()

        for (level in 1..PrefsManager.MAX_LEVELS) {
            val rowView = inflater.inflate(R.layout.item_level_row, binding.levelsContainer, false)
            val label = rowView.findViewById<TextView>(R.id.tvLevelLabel)
            val editText = rowView.findViewById<EditText>(R.id.etLevelAmount)
            label.text = "Level $level"
            editText.hint = "Amount"
            binding.levelsContainer.addView(rowView)
            levelEditTexts.add(editText)
        }
    }

    private fun loadSavedConfiguration() {
        val target = prefsManager.getTarget()
        if (target == BetTarget.BIG) {
            binding.rbBig.isChecked = true
        } else {
            binding.rbSmall.isChecked = true
        }
        updateTargetSegmentColors()

        binding.etBaseAmount.setText(prefsManager.getQuickFillBase().toString())
        if (prefsManager.getQuickFillMultiplier() == 3) {
            binding.rbMult3x.isChecked = true
        } else {
            binding.rbMult2x.isChecked = true
        }
        updateMultiplierSegmentColors()

        val savedAmounts = prefsManager.getLevelAmounts()
        savedAmounts.forEachIndexed { index, amount ->
            levelEditTexts.getOrNull(index)?.setText(amount.toString())
        }
    }

    private fun bindListeners() {
        binding.btnEnableAccessibility.setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        binding.btnGrantOverlay.setOnClickListener {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivity(intent)
        }

        binding.rgTarget.setOnCheckedChangeListener { _, _ ->
            updateTargetSegmentColors()
        }

        binding.rgMultiplier.setOnCheckedChangeListener { _, _ ->
            updateMultiplierSegmentColors()
        }

        binding.btnQuickFill.setOnClickListener {
            applyQuickFill()
        }

        binding.btnSaveConfig.setOnClickListener {
            if (saveCurrentInputs()) {
                Toast.makeText(this, "Configuration saved", Toast.LENGTH_SHORT).show()
            }
        }

        binding.btnLaunchOverlay.setOnClickListener {
            if (!isAccessibilityServiceEnabled()) {
                Toast.makeText(
                    this,
                    "Please enable the Accessibility Service first",
                    Toast.LENGTH_LONG
                ).show()
                return@setOnClickListener
            }
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(
                    this,
                    "Please grant Display Over Other Apps permission first",
                    Toast.LENGTH_LONG
                ).show()
                return@setOnClickListener
            }
            if (!saveCurrentInputs()) return@setOnClickListener

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.POST_NOTIFICATIONS
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            } else {
                startOverlayAndMinimize()
            }
        }
    }

    private fun applyQuickFill() {
        val base = binding.etBaseAmount.text.toString().trim().toLongOrNull()
        if (base == null || base < 1L) {
            Toast.makeText(this, "Enter a valid Base Amount (>= 1)", Toast.LENGTH_SHORT).show()
            return
        }
        val mult = if (binding.rbMult3x.isChecked) 3L else 2L
        prefsManager.saveQuickFill(base.toInt(), mult.toInt())

        var current = base
        for (index in 0 until PrefsManager.MAX_LEVELS) {
            levelEditTexts[index].setText(current.toString())
            current = (current * mult).coerceAtMost(10_000_000L)
        }
        Toast.makeText(this, "Populated 15 levels (${mult}x from ₹$base)", Toast.LENGTH_SHORT).show()
    }

    private fun saveCurrentInputs(): Boolean {
        val target = if (binding.rbSmall.isChecked) BetTarget.SMALL else BetTarget.BIG
        val amounts = mutableListOf<Int>()

        for ((index, editText) in levelEditTexts.withIndex()) {
            val raw = editText.text.toString().trim()
            val value = raw.toIntOrNull()
            if (value == null || value < 1) {
                editText.error = "Required >= 1"
                editText.requestFocus()
                Toast.makeText(
                    this,
                    "Level ${index + 1} must be at least ₹1",
                    Toast.LENGTH_SHORT
                ).show()
                return false
            }
            amounts.add(value)
        }

        prefsManager.saveConfiguration(target, amounts)
        return true
    }

    private fun startOverlayAndMinimize() {
        val intent = Intent(this, OverlayService::class.java)
        ContextCompat.startForegroundService(this, intent)
        moveTaskToBack(true)
    }

    private fun updateTargetSegmentColors() {
        val bigActive = binding.rbBig.isChecked
        binding.rbBig.setBackgroundResource(if (bigActive) R.drawable.bg_badge_granted else 0)
        binding.rbSmall.setBackgroundResource(if (!bigActive) R.drawable.bg_badge_granted else 0)
        binding.rbBig.setTextColor(
            ContextCompat.getColor(
                this,
                if (bigActive) R.color.accent_green else R.color.text_secondary
            )
        )
        binding.rbSmall.setTextColor(
            ContextCompat.getColor(
                this,
                if (!bigActive) R.color.accent_green else R.color.text_secondary
            )
        )
    }

    private fun updateMultiplierSegmentColors() {
        val is3x = binding.rbMult3x.isChecked
        binding.rbMult2x.setBackgroundResource(if (!is3x) R.drawable.bg_card else 0)
        binding.rbMult3x.setBackgroundResource(if (is3x) R.drawable.bg_card else 0)
        binding.rbMult2x.setTextColor(
            ContextCompat.getColor(
                this,
                if (!is3x) R.color.text_primary else R.color.text_secondary
            )
        )
        binding.rbMult3x.setTextColor(
            ContextCompat.getColor(
                this,
                if (is3x) R.color.text_primary else R.color.text_secondary
            )
        )
    }

    private fun refreshPermissionBadges() {
        val accGranted = isAccessibilityServiceEnabled()
        binding.tvAccessibilityStatus.text =
            getString(if (accGranted) R.string.status_granted else R.string.status_missing)
        binding.tvAccessibilityStatus.setBackgroundResource(
            if (accGranted) R.drawable.bg_badge_granted else R.drawable.bg_badge_missing
        )
        binding.tvAccessibilityStatus.setTextColor(
            ContextCompat.getColor(
                this,
                if (accGranted) R.color.accent_green else R.color.accent_red
            )
        )

        val overlayGranted = Settings.canDrawOverlays(this)
        binding.tvOverlayStatus.text =
            getString(if (overlayGranted) R.string.status_granted else R.string.status_missing)
        binding.tvOverlayStatus.setBackgroundResource(
            if (overlayGranted) R.drawable.bg_badge_granted else R.drawable.bg_badge_missing
        )
        binding.tvOverlayStatus.setTextColor(
            ContextCompat.getColor(
                this,
                if (overlayGranted) R.color.accent_green else R.color.accent_red
            )
        )
    }

    private fun isAccessibilityServiceEnabled(): Boolean {
        val expectedComponent = ComponentName(this, K3AccessibilityService::class.java)
        val enabledServices = Settings.Secure.getString(
            contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false

        val splitter = TextUtils.SimpleStringSplitter(':')
        splitter.setString(enabledServices)
        while (splitter.hasNext()) {
            val component = ComponentName.unflattenFromString(splitter.next())
            if (component == expectedComponent) {
                return true
            }
        }
        return false
    }
}
