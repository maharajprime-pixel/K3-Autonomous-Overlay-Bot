package com.k3bot.overlay.service

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.graphics.Rect
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleService
import androidx.lifecycle.lifecycleScope
import com.k3bot.overlay.R
import com.k3bot.overlay.data.BotCommand
import com.k3bot.overlay.data.BotCoordinator
import com.k3bot.overlay.data.BotState
import com.k3bot.overlay.data.BotTelemetry
import com.k3bot.overlay.data.PrefsManager
import com.k3bot.overlay.databinding.LayoutOverlayWidgetBinding
import com.k3bot.overlay.ui.MainActivity
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import kotlin.math.abs

class OverlayService : LifecycleService() {

    private lateinit var windowManager: WindowManager
    private lateinit var prefsManager: PrefsManager
    private lateinit var binding: LayoutOverlayWidgetBinding
    private lateinit var layoutParams: WindowManager.LayoutParams

    private var isCollapsed = false
    private var lastAlertState: BotState? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        prefsManager = PrefsManager(this)

        createNotificationChannel()
        startForegroundCompat()
        setupOverlayView()
        observeTelemetry()

        val initialTarget = prefsManager.getTarget()
        val initialLevel1 = prefsManager.getAmountForLevel(1)
        BotCoordinator.updateTelemetry {
            it.copy(
                target = initialTarget,
                currentLevel = 1,
                currentAmount = initialLevel1
            )
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        return START_STICKY
    }

    private fun startForegroundCompat() {
        val openAppIntent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            openAppIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val notification: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("K3 Autonomous Overlay Active")
            .setContentText("Tap to open configuration")
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setOngoing(true)
            .setContentIntent(pendingIntent)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                getString(R.string.notification_channel_name),
                NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun setupOverlayView() {
        binding = LayoutOverlayWidgetBinding.inflate(LayoutInflater.from(this))

        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val (savedX, savedY) = prefsManager.getOverlayPosition()
        layoutParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = savedX
            y = savedY
        }

        windowManager.addView(binding.root, layoutParams)
        binding.root.post { publishOverlayBounds() }

        attachDragListener(binding.dragHandle) { /* header drag only */ }
        attachDragListener(binding.collapsedBubble) { toggleCollapsed(false) }

        binding.btnMinimize.setOnClickListener {
            toggleCollapsed(true)
        }

        binding.btnTargetChip.setOnClickListener {
            val current = BotCoordinator.telemetry.value
            if (current.isRunning) {
                Toast.makeText(this, "Stop bot before switching target", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val nextTarget = current.target.toggled()
            prefsManager.setTarget(nextTarget)
        }

        binding.btnToggleBot.setOnClickListener {
            val current = BotCoordinator.telemetry.value
            if (current.isRunning) {
                BotCoordinator.sendCommand(BotCommand.Stop)
            } else {
                if (!BotCoordinator.isAccessibilityConnected) {
                    Toast.makeText(
                        this,
                        "Accessibility Service not connected",
                        Toast.LENGTH_LONG
                    ).show()
                    return@setOnClickListener
                }
                BotCoordinator.sendCommand(BotCommand.Start)
            }
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun attachDragListener(targetView: View, onSingleTap: () -> Unit) {
        var initialX = 0
        var initialY = 0
        var initialTouchX = 0f
        var initialTouchY = 0f
        var moved = false

        targetView.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = layoutParams.x
                    initialY = layoutParams.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - initialTouchX).toInt()
                    val dy = (event.rawY - initialTouchY).toInt()
                    if (abs(dx) > 8 || abs(dy) > 8) moved = true
                    layoutParams.x = initialX + dx
                    layoutParams.y = initialY + dy
                    windowManager.updateViewLayout(binding.root, layoutParams)
                    publishOverlayBounds()
                    true
                }
                MotionEvent.ACTION_UP -> {
                    prefsManager.saveOverlayPosition(layoutParams.x, layoutParams.y)
                    publishOverlayBounds()
                    if (!moved) onSingleTap()
                    true
                }
                else -> false
            }
        }
    }

    private fun toggleCollapsed(collapse: Boolean) {
        isCollapsed = collapse
        binding.expandedContainer.visibility = if (collapse) View.GONE else View.VISIBLE
        binding.collapsedBubble.visibility = if (collapse) View.VISIBLE else View.GONE
        binding.root.post { publishOverlayBounds() }
    }

    private fun publishOverlayBounds() {
        val loc = IntArray(2)
        binding.root.getLocationOnScreen(loc)
        BotCoordinator.overlayBounds = Rect(
            loc[0],
            loc[1],
            loc[0] + binding.root.width,
            loc[1] + binding.root.height
        )
    }

    private fun observeTelemetry() {
        lifecycleScope.launch {
            BotCoordinator.telemetry.collectLatest { telemetry ->
                renderTelemetry(telemetry)
            }
        }
    }

    private fun renderTelemetry(telemetry: BotTelemetry) {
        binding.tvOverlayStatus.text = telemetry.state.displayText
        binding.tvOverlayPeriod.text = telemetry.currentPeriod
        binding.tvOverlayLevel.text = "Level ${telemetry.currentLevel} / ${PrefsManager.MAX_LEVELS}"
        binding.tvOverlayAmount.text = "₹${telemetry.currentAmount}"
        binding.btnTargetChip.text = telemetry.target.label
        binding.btnTargetChip.alpha = if (telemetry.isRunning) 0.5f else 1.0f
        binding.tvBubbleLabel.text = "L${telemetry.currentLevel}"

        val statusColor = when (telemetry.state) {
            BotState.IDLE -> R.color.text_secondary
            BotState.WAITING_FOR_NEXT_ROUND -> R.color.accent_amber
            BotState.PLACING_BET, BotState.VERIFYING_RESULT -> R.color.accent_green
            BotState.STOPPED_LEVEL_15_LIMIT, BotState.STOPPED_UI_ERROR -> R.color.accent_red
        }
        binding.tvOverlayStatus.setTextColor(ContextCompat.getColor(this, statusColor))

        if (telemetry.isRunning) {
            binding.btnToggleBot.text = "STOP"
            binding.btnToggleBot.backgroundTintList =
                ContextCompat.getColorStateList(this, R.color.accent_red)
        } else {
            binding.btnToggleBot.text = "START"
            binding.btnToggleBot.backgroundTintList =
                ContextCompat.getColorStateList(this, R.color.accent_green)
        }

        if (telemetry.state.isStoppedError && lastAlertState != telemetry.state) {
            lastAlertState = telemetry.state
            triggerSafetyAlert()
        } else if (!telemetry.state.isStoppedError) {
            lastAlertState = null
        }
    }

    private fun triggerSafetyAlert() {
        runCatching {
            val tone = ToneGenerator(AudioManager.STREAM_ALARM, 90)
            tone.startTone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD, 600)
        }
        runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vm = getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
                vm.defaultVibrator.vibrate(
                    VibrationEffect.createOneShot(600, VibrationEffect.DEFAULT_AMPLITUDE)
                )
            } else {
                @Suppress("DEPRECATION")
                val vibrator = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    vibrator.vibrate(
                        VibrationEffect.createOneShot(600, VibrationEffect.DEFAULT_AMPLITUDE)
                    )
                } else {
                    @Suppress("DEPRECATION")
                    vibrator.vibrate(600)
                }
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        if (::binding.isInitialized) {
            runCatching { windowManager.removeView(binding.root) }
        }
        BotCoordinator.overlayBounds = Rect(0, 0, 0, 0)
    }

    companion object {
        private const val CHANNEL_ID = "k3_overlay_service_channel"
        private const val NOTIFICATION_ID = 1001
    }
}
