package com.k3bot.overlay.data

import android.content.Context
import android.content.SharedPreferences

class PrefsManager(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun getTarget(): BetTarget {
        val raw = prefs.getString(KEY_TARGET, BetTarget.BIG.name) ?: BetTarget.BIG.name
        return runCatching { BetTarget.valueOf(raw) }.getOrDefault(BetTarget.BIG)
    }

    fun setTarget(target: BetTarget) {
        prefs.edit().putString(KEY_TARGET, target.name).apply()
        BotCoordinator.updateTelemetry { it.copy(target = target) }
    }

    fun getLevelAmounts(): List<Int> {
        return (1..MAX_LEVELS).map { level ->
            prefs.getInt("$KEY_LEVEL_PREFIX$level", defaultAmountForLevel(level))
                .coerceAtLeast(1)
        }
    }

    fun getAmountForLevel(level: Int): Int {
        val clamped = level.coerceIn(1, MAX_LEVELS)
        return prefs.getInt("$KEY_LEVEL_PREFIX$clamped", defaultAmountForLevel(clamped))
            .coerceAtLeast(1)
    }

    fun saveConfiguration(target: BetTarget, levelAmounts: List<Int>) {
        require(levelAmounts.size == MAX_LEVELS) {
            "Expected exactly $MAX_LEVELS progression levels"
        }
        val editor = prefs.edit()
        editor.putString(KEY_TARGET, target.name)
        levelAmounts.forEachIndexed { index, amount ->
            editor.putInt("$KEY_LEVEL_PREFIX${index + 1}", amount.coerceAtLeast(1))
        }
        editor.apply()

        val activeLevel = BotCoordinator.telemetry.value.currentLevel.coerceIn(1, MAX_LEVELS)
        BotCoordinator.updateTelemetry {
            it.copy(
                target = target,
                currentAmount = levelAmounts[activeLevel - 1]
            )
        }
        BotCoordinator.sendCommand(BotCommand.ConfigUpdated)
    }

    fun getQuickFillBase(): Int = prefs.getInt(KEY_QUICK_BASE, 10)

    fun getQuickFillMultiplier(): Int = prefs.getInt(KEY_QUICK_MULT, 2)

    fun saveQuickFill(base: Int, multiplier: Int) {
        prefs.edit()
            .putInt(KEY_QUICK_BASE, base.coerceAtLeast(1))
            .putInt(KEY_QUICK_MULT, multiplier.coerceIn(2, 3))
            .apply()
    }

    fun getOverlayPosition(): Pair<Int, Int> {
        return prefs.getInt(KEY_OVERLAY_X, 24) to prefs.getInt(KEY_OVERLAY_Y, 220)
    }

    fun saveOverlayPosition(x: Int, y: Int) {
        prefs.edit()
            .putInt(KEY_OVERLAY_X, x)
            .putInt(KEY_OVERLAY_Y, y)
            .apply()
    }

    companion object {
        private const val PREFS_NAME = "k3_overlay_bot_prefs"
        private const val KEY_TARGET = "fixed_target"
        private const val KEY_LEVEL_PREFIX = "level_amount_"
        private const val KEY_QUICK_BASE = "quick_fill_base"
        private const val KEY_QUICK_MULT = "quick_fill_mult"
        private const val KEY_OVERLAY_X = "overlay_x"
        private const val KEY_OVERLAY_Y = "overlay_y"
        const val MAX_LEVELS = 15

        private fun defaultAmountForLevel(level: Int): Int {
            var amount = 10L
            repeat(level - 1) {
                amount = (amount * 2L).coerceAtMost(500_000L)
            }
            return amount.toInt()
        }
    }
}
